<?php
if( !class_exists( 'wd_widget_brand_slider' ) ) {
	class wd_widget_brand_slider extends WP_Widget {
		protected $list_widget_field_default = array(
			'source'		=> '1',
			'brands'		=> '-1',
			'image_url'		=> '',
			'image_size'	=> 'full',
			'is_slider'		=> '1',
			'columns'		=> '5',
			'columns_tablet' => 2,
			'columns_mobile' => 1,
			'show_nav'		=> '1',
			'auto_play'		=> '1',
			'class' 		=> ''
		);
		
	    function __construct() {
	    	$widget_setting = array(
				'name' 		=> esc_html__('WD - Brand Slider','wd_package'),
				'desc' 		=> esc_html__('Display Brand/Image Slider...','wd_package'),
				'slug' 	  	=> 'widget_brand_slider',
			);
			$widget_ops 		= array('classname' => $widget_setting['slug'], 'description' => $widget_setting['desc']);
			$control_ops 		= array('width' => 400, 'height' => 350);
			parent::__construct($widget_setting['slug'], $widget_setting['name'], $widget_ops);
		}

		function form( $instance ) {
	       	foreach ($this->list_widget_field_default as $key => $value) {
	    		${$key}   	= isset( $instance[$key] ) ? esc_attr( $instance[$key] ) : $value;
	    	}

	    	global $_wp_additional_image_sizes;
			$image_size_arr = array();
			$image_size_arr['full'] = 'Full';
			foreach ($_wp_additional_image_sizes as $key => $value) {
				$image_size_arr[$key] = $key.' - '.$value['width'].'x'.$value['height'];
			} 

			$columns_arr = array(
				 '1' =>__( '1 Columns', 'wd_package' ),
				 '2' =>__( '2 Columns', 'wd_package' ),
				 '3' =>__( '3 Columns', 'wd_package' ),
				 '4' =>__( '4 Columns', 'wd_package' ),
				 '5' =>__( '5 Columns', 'wd_package' ),
				 '6' =>__( '6 Columns', 'wd_package' ),
				 '8' =>__( '8 Columns', 'wd_package' ),
				 '12' =>__( '12 Columns', 'wd_package' ),
			);

			$is_slider_arr = array(
				'1'			=> esc_html__('Yes','wd_package'),
				'0'			=> esc_html__('No','wd_package'),
			);
			$show_nav_arr = array(
				'1'			=> esc_html__('Yes','wd_package'),
				'0'			=> esc_html__('No','wd_package'),
			);
			$auto_play_arr = array(
				'1'			=> esc_html__('Yes','wd_package'),
				'0'			=> esc_html__('No','wd_package'),
			);
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('image_size')); ?>"><?php esc_html_e('Image Size:','wd_package'); ?></label>
				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name('image_size')); ?>" id="<?php echo esc_attr($this->get_field_id('image_size')); ?>">
					<?php foreach( $image_size_arr as $key => $value ){ ?>
					<option value="<?php echo esc_attr($key); ?>" <?php echo ($image_size==$key)?'selected':'' ?> ><?php echo esc_attr($value); ?></option>
					<?php } ?>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('columns')); ?>"><?php esc_html_e('Columns:','wd_package'); ?></label>
				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name('columns')); ?>" id="<?php echo esc_attr($this->get_field_id('columns')); ?>">
					<?php foreach( $columns_arr as $key => $value ){ ?>
					<option value="<?php echo esc_attr($key); ?>" <?php echo ($columns==$key)?'selected':'' ?> ><?php echo esc_attr($value); ?></option>
					<?php } ?>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('is_slider')); ?>"><?php esc_html_e('Is Slider:','wd_package'); ?></label>
				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name('is_slider')); ?>" id="<?php echo esc_attr($this->get_field_id('is_slider')); ?>">
					<?php foreach( $is_slider_arr as $key => $value ){ ?>
					<option value="<?php echo esc_attr($key); ?>" <?php echo ($is_slider==$key)?'selected':'' ?> ><?php echo esc_attr($value); ?></option>
					<?php } ?>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('show_nav')); ?>"><?php esc_html_e('Show nav:','wd_package'); ?></label>
				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name('show_nav')); ?>" id="<?php echo esc_attr($this->get_field_id('show_nav')); ?>">
					<?php foreach( $show_nav_arr as $key => $value ){ ?>
					<option value="<?php echo esc_attr($key); ?>" <?php echo ($show_nav==$key)?'selected':'' ?> ><?php echo esc_attr($value); ?></option>
					<?php } ?>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('auto_play')); ?>"><?php esc_html_e('Auto Play:','wd_package'); ?></label>
				<select class="widefat" name="<?php echo esc_attr( $this->get_field_name('auto_play')); ?>" id="<?php echo esc_attr($this->get_field_id('auto_play')); ?>">
					<?php foreach( $auto_play_arr as $key => $value ){ ?>
					<option value="<?php echo esc_attr($key); ?>" <?php echo ($auto_play==$key)?'selected':'' ?> ><?php echo esc_attr($value); ?></option>
					<?php } ?>
				</select>
			</p>
            <p>
                <label for="<?php echo $this->get_field_id( 'class' ); ?>"><?php esc_html_e( 'Extra class name:', 'wd_package' ); ?>
                <input class="widefat" id="<?php echo $this->get_field_id( 'class' ); ?>" name="<?php echo $this->get_field_name( 'class' ); ?>" type="text" value="<?php echo $class; ?>" />
                </label>
            </p>
        <?php
	    }
	    function widget( $args, $instance ){
	    	extract($args);
	        echo $before_widget;
	        	echo wd_brand_slider_function($instance);
	        echo $after_widget;
	    }
	    function update( $new_instance, $old_instance ){
	        $instance = $old_instance;
	        foreach ($this->list_widget_field_default as $key => $value) {
	    		$instance[$key]   = isset( $instance[$key] ) ? strip_tags( $new_instance[$key] ) : $value;
	    	}
	        return $instance;
	    }
	}
	function wp_widget_register_widget_brand_slider() {
		register_widget( 'wd_widget_brand_slider' );
	}
	add_action( 'widgets_init', 'wp_widget_register_widget_brand_slider' );
}