<?php 
/**
 * woocommerce_currency_converter class
 **/
if (!class_exists('WD_Shop_Currency_Converter')) {
	class WD_Shop_Currency_Converter {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		var $base;
		var $currency;
		var $rates;
		protected $arrShortcodes 		= array('currency_switcher');

		public function __construct() {
			$this->constant();
			//$this->initWidgets();
			$this->get_rates_currency();
			// Actions
			add_action('wp_enqueue_scripts', array( $this, 'currency_conversion_lybrary'));
			add_action('woocommerce_checkout_update_order_meta', array( $this, 'update_order_meta'));
			add_action('widgets_init', array( $this, 'register_widgets'));

			// Settings
			add_filter( 'woocommerce_settings_tabs_array', array( $this, 'register_setting_tab'), 50 );
			add_action( 'woocommerce_settings_tabs_wd_currency_switcher_setting', array($this, 'settings_tab') );
			add_action( 'woocommerce_update_options_wd_currency_switcher_setting', array($this, 'update_settings') );
			
			//$this->get_form_currency_convert($list_currency);

			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}
		}

		function register_setting_tab( $settings_tabs ) {
				$settings_tabs['wd_currency_switcher_setting'] = __( 'WD Currency Switcher', 'wd_package' );
			return $settings_tabs;
		}

		function get_woocommerce_currencies() {
			$list_woo_currency 	= get_woocommerce_currencies();
			$list_currency 		= array(); 
			if (count($list_woo_currency)) {
				foreach ($list_woo_currency as $symbol => $name) {
					$list_currency[$symbol] = $name.' ('.$symbol.')';
				}
			}
			return $list_currency;
		}	
		
		function get_settings() {
			$settings = array(
				'section_title' => array(
					'name'     => __( 'Currency Switcher Settings', 'wd_package' ),
					'type'     => 'title',
					'desc'     => '',
					'id'       => 'wc_wd_currency_switcher_setting_section_title'
				),
				'currency' => array(
					'name'     => __( 'Currency', 'wd_package' ),
					'desc_tip' => __( '', 'wd_package' ),
					'id'       => 'wc_currency_converter_set_currency',
					'type'     => 'multiselect',
					'css'      => 'min-width:500px;min-height:500px;',
					'desc'     => __( 'Ctrl + left mouse click to select multiple lines.', 'wd_package'),
					'options'  => $this->get_woocommerce_currencies(),
					'default'  => array('USD', 'EUR', 'VND'),
				),
				'api_key' => array(
					'name' => __( 'API Key', 'wd_package' ),
					'type' => 'text',
					'desc' => sprintf( __('(optional) If you have an <a href="%s">Open Exchange Rate API app ID</a>, enter it here.', 'wd_package'), 'https://openexchangerates.org/signup' ),
					'id'   => 'wc_currency_converter_api_id'
				),
				'section_end' => array(
						'type' => 'sectionend',
						'id' => 'wc_wd_currency_switcher_setting_section_end'
				)
			);
			return apply_filters( 'wc_wd_currency_switcher_setting_settings', $settings );
		}	

		function settings_tab() {
			woocommerce_admin_fields( $this->get_settings() );
		}

		function update_settings() {
			woocommerce_update_options( $this->get_settings() );
		}

		function get_rates_currency(){
			if ( false === ( $rates = get_transient( 'woocommerce_currency_converter_rates' ) ) ) {

				$app_id = get_option( 'wc_currency_converter_api_id' ) ? get_option( 'wc_currency_converter_api_id' ) : 'e65018798d4a4585a8e2c41359cc7f3c';

				$rates = wp_remote_retrieve_body( wp_remote_get( 'http://openexchangerates.org/api/latest.json?app_id=' . $app_id ) );

				// Cache for 12 hours
				if ( $rates )
					set_transient( 'woocommerce_currency_converter_rates', $rates, 60*60*12 );
			}

			$rates = json_decode( $rates );

			if ( $rates ) {
				$this->base		= $rates->base;
				$this->rates 	= $rates->rates;
			}
		}

		/*-----------------------------------------------------------------------------------*/
		/* Class Functions */
		/*-----------------------------------------------------------------------------------*/
		protected function constant(){
			define('WDSCS_BASE'		,   plugin_dir_path( __FILE__ )		);
			define('WDSCS_BASE_URI'	,   plugins_url( '', __FILE__ )		);
			define('WDSCS_JS'		, 	WDSCS_BASE_URI . '/assets/js'	);
			define('WDSCS_CSS'		, 	WDSCS_BASE_URI . '/assets/css'	);
			define('WDSCS_TEMPLATE' , 	WDSCS_BASE . '/templates'		);
			define('WDSCS_WIDGET' 	, 	WDSCS_BASE . '/widgets'		);
		}

		protected function initWidgets(){
			foreach($this->arrShortcodes as $widget){
				if( file_exists(WDSCS_WIDGET."/wd_{$widget}_widget.php") ){
					require_once WDSCS_WIDGET."/wd_{$widget}_widget.php";
				}	
			}
		}
		
		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(WDSCS_TEMPLATE."/wd_{$shortcode}.php") ){
					require_once WDSCS_TEMPLATE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(WDSCS_TEMPLATE."/wd_vc_{$visual}.php") ){
					require_once WDSCS_TEMPLATE."/wd_vc_{$visual}.php";
				}
			}
		} 

		function register_widgets() {
			if (class_exists('WooCommerce_Widget_Currency_Converter')) {
				register_widget('WooCommerce_Widget_Currency_Converter');
			}
		}

		function currency_conversion_lybrary() {
			if ( is_admin() )
				return;
			//Style
			wp_enqueue_style( 'wd-currency-converter-styles', WDSCS_CSS. '/converter.css' );
			wp_enqueue_style( 'currency-flags', WDSCS_CSS. '/currency-flags.min.css' );

			// Scripts
			wp_enqueue_script( 'money-js', WDSCS_JS. '/money.min.js', array( 'jquery' ), '0.1.3', true );
			wp_enqueue_script( 'accounting-js', WDSCS_JS. '/accounting.min.js', array( 'jquery' ), '0.3.2', true );
			wp_enqueue_script( 'jquery-cookie', WDSCS_JS. '/jquery-cookie/jquery.cookie.min.js', array( 'jquery' ), '1.3.1', true );
			wp_enqueue_script( 'wd-conversion-js', WDSCS_JS. '/conversion.min.js', array( 'jquery', 'money-js', 'accounting-js', 'jquery-cookie' ), '1.2.3', true );
			wp_enqueue_script( 'wd-currency-converter-script', WDSCS_JS. '/wd-scripts.js', array( 'jquery'), false, true );

			$symbols = array();
			if ( function_exists( 'get_woocommerce_currencies' ) ) {
				$codes   = get_woocommerce_currencies();
				foreach ( $codes as $code => $name )
					$symbols[ $code ]         = get_woocommerce_currency_symbol( $code );
			}

			$zero_replace = '.';
			for ( $i = 0; $i < absint( get_option( 'woocommerce_price_num_decimals' ) ); $i++ )
				$zero_replace .= '0';

			$wc_currency_converter_params = array(
				'current_currency' => isset( $_COOKIE['woocommerce_current_currency'] ) ? $_COOKIE['woocommerce_current_currency'] : '',
				'currencies'       => json_encode( $symbols ),
				'rates'            => $this->rates,
				'base'             => $this->base,
				'currency'         => get_option( 'woocommerce_currency' ),
				'currency_pos'     => get_option( 'woocommerce_currency_pos' ),
				'num_decimals'     => absint( get_option( 'woocommerce_price_num_decimals' ) ),
				'trim_zeros'       => get_option( 'woocommerce_price_trim_zeros' ) == 'yes' ? true : false,
				'thousand_sep'     => get_option( 'woocommerce_price_thousand_sep' ),
				'decimal_sep'      => get_option( 'woocommerce_price_decimal_sep' ),
				'i18n_oprice'      => __( 'Original price:', 'wd_package'),
				'zero_replace'     => $zero_replace
			);

			wp_localize_script( 'wd-conversion-js', 'wc_currency_converter_params', apply_filters( 'wc_currency_converter_params', $wc_currency_converter_params ) );
		}

		function update_order_meta( $order_id ) {
			global $woocommerce;

			if (isset($_COOKIE['woocommerce_current_currency']) && $_COOKIE['woocommerce_current_currency']) {

				update_post_meta( $order_id, 'Viewed Currency', $_COOKIE['woocommerce_current_currency'] );

				$order_total = number_format($woocommerce->cart->total, 2, '.', '');

				$store_currency = get_option('woocommerce_currency');
				$target_currency = $_COOKIE['woocommerce_current_currency'];

				if ($store_currency && $target_currency && $this->rates->$target_currency && $this->rates->$store_currency) {

					$new_order_total = ( $order_total / $this->rates->$store_currency ) * $this->rates->$target_currency;

					$new_order_total = round($new_order_total, 2) . ' ' . $target_currency;

					update_post_meta( $order_id, 'Converted Order Total', $new_order_total );

				}

			}
		}

		public function get_form_currency_convert($list_currency = array('USD')){
			if( count($list_currency) == 0 ) return;
			if( class_exists('WooCommerce_Widget_Currency_Converter') && class_exists('WooCommerce') ){
				$list_currencies = get_woocommerce_currencies();
				$currency_symbol = get_woocommerce_currency_symbol('USD');
				?>
				<div class="currency_control">
					<a href="javascript: void(0)">
						<span class="current_currency"><?php echo get_option( 'woocommerce_currency' ); ?></span>
						<span class="symbol"></span>
					</a>
				</div>
				<div class="currency_dropdown drop_down_container" style="display: none">
					<form method="post">
						<div>
							<?php
								if ( $list_currency ) {
	
									echo '<ul class="currency_switcher font-second">';
	
									foreach ( $list_currency as $currency ) {
	
										$class    = '';
	
										if ( $currency == get_option( 'woocommerce_currency' ) )
											$class = 'reset default';
										$text_line = '';
										$text_line .= '<span class="name">'.esc_html($currency).'</span>';
										$text_line .= '<span class="symbol">'.esc_html(get_woocommerce_currency_symbol($currency)).'</span>';
										echo '<li><a href="#" class="' . esc_attr( $class ) . '" data-currencycode="' . esc_attr( $currency ) . '">' . $text_line . '</a></li>';
									}
	
									echo '</ul>';
								}
							?>
						</div>
					</form>
				</div>
				<?php
			}
		}

		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}

	}

	WD_Shop_Currency_Converter::get_instance();
}