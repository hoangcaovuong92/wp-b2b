<?php 
if ( ! function_exists( 'wd_get_future_content_item' ) ) {
	function wd_get_future_content_item($args = array()) {
		global $post;
		$post_id = $post->ID;
		$default = array(
			'type' 						=> 'single',
			'show_icon_font_thumbnail'	=> 'show-icon',
			'feature_icon_or_custom_icon' => 'feature_icon',
			'icon_fontawesome' 			=> 'fa fa-heartbeat',
			'text_align'				=> 'wd-text-align-default',
			'icon_size'					=> 'fa-1x',
			'style_font'				=> 'sync-with-title',
			'image_or_thumbnail'		=> 'feature-thumbnail',
			'custom_image'				=> '',
			'image_size'				=> 'full',
			'title'						=> '1',
			'show_excerpt'				=> '1',
			'number_word'				=> '10',
			'open_link_with'			=> 'modal',
			'readmore'					=> '1',
			'readmore_text'				=> 'Read More',
			'style_class'				=> 'style-1',
		);

		extract(wp_parse_args( $args, $default ));
		$custom_class	= ($style_class == 'style-2' || $style_class == 'style-4' || $style_class == 'style-6'|| $style_class == 'style-7' || $style_class == 'style-11') ? 'wd-feature-thumbnail-left-content' : '' ;
		$classes[] 		= ($type == 'multi') ? 'wd-feature-content-list-item' : 'wd-shortcode-feature-single';
		$classes[] 		= 'wd-feature-'.$style_class;
		$classes[] 		= $custom_class;
		$classes[] 		= $text_align;

		$title 		= ($title) ? '<h3 class="wd-feature-item-title heading_title">' .get_the_title().'</h3>' : '';
		$excerpt    = ($number_word) ?  wp_trim_words(get_the_excerpt(), $number_word, '...') : get_the_excerpt();  
		$excerpt    = ($show_excerpt && $excerpt) ? '<div class="wd-feature-item-excerpt">'. $excerpt.'</div>' : '';
		$thumbnail 	= '';
		$meta_data 	= unserialize(get_post_meta($post_id,'wd_feature_meta_data',true));

		if ($show_icon_font_thumbnail == 'show-icon') { //display icon font class
			if ($feature_icon_or_custom_icon == 'feature_icon') {
				$icon_fontawesome 	= (!empty($meta_data['wd_feature']['wd_feature_icon'])) ? $meta_data['wd_feature']['wd_feature_icon'] : $icon_fontawesome;
			}
			$icon_fontawesome 	= (!empty($icon_fontawesome)) ? $icon_fontawesome : 'fa fa-heartbeat';

			if ($style_font == 'separate-from-title') {
				$thumbnail 	= '<div class="wd-feature-item-icon"><span class="'. esc_attr($icon_size) .' '. esc_attr($icon_fontawesome).'"></span></div>';
			}else{
				$title 		= '<h3 class="wd-feature-item-title heading_title"><i class="'. esc_attr($icon_size) .' '. esc_attr($icon_fontawesome).'"></i>'.get_the_title().'</h3>';
			}
		}elseif($show_icon_font_thumbnail == 'show-image'){ //display thumbnail
			if ($image_or_thumbnail == 'custom-image' && $custom_image) {
				$thumbnail_image = wp_get_attachment_image($custom_image, $image_size);
			}else if ($image_or_thumbnail == 'feature-thumbnail' && has_post_thumbnail() && get_the_post_thumbnail()) {
				$thumbnail_image =  get_the_post_thumbnail($post_id, $image_size, array( 'alt' => esc_attr(get_the_title()), 'title' => esc_attr(get_the_title()) ) );
			}else{
				$thumbnail_image = '<img src="'.WDFT_IMAGE.'/no-image.jpg" alt="'.esc_attr(get_the_title()).'" title="'.esc_attr(get_the_title()).'"  />';
			}
			$thumbnail .= '<div class="wd-feature-item-thumbnail">'.$thumbnail_image.'</div>';
		}

		$url 			= (!empty($meta_data['wd_feature']['wd_feature_url']) && $open_link_with == 'link') ? $meta_data['wd_feature']['wd_feature_url'] : '#'; 
		$link_class		= ($open_link_with == 'modal') ? 'wd-modal-bootstrap-ajax' : '';

		$readmore_text 	= ($readmore_text == '' && !empty($meta_data['wd_feature']['wd_readmore_text'])) ? $meta_data['wd_feature']['wd_readmore_text'] : $readmore_text;
		$readmore_text 	= ($readmore_text == '') ? esc_html('Read More','wd_package') : $readmore_text;
		$readmore 		= ($readmore && $readmore_text) ? '<div class="wd-feature-item-readmore"><a data-feature_id="'.get_the_ID().'" class="wd-feature-readmore '.esc_attr($link_class).'" href="'.esc_url($url).'">'.esc_html($readmore_text).'</a></div>' : '<div class="wd-feature-item-readmore"></div>';

		$loading_icon 	= ($open_link_with == 'modal') ? '<div id="wd-feature-loading-'.get_the_ID().'" class="wd-feature-loading-img hidden"><img src="'.SC_IMAGE.'/loading.gif" alt="Loading Icon"></div>' : '';

		ob_start(); ?>
			<?php if ($type == "multi"): ?>
				<li id="wd-feature-<?php the_ID(); ?>" <?php post_class($classes); ?>>
			<?php else: ?>
				<div id="wd-feature-<?php the_ID(); ?>" <?php post_class($classes); ?>>
			<?php endif ?>
				<?php if ($style_class == 'style-5'): ?>
					<?php echo $title; ?>
					<?php echo $thumbnail; ?>
					<?php echo $excerpt; ?>
					<?php echo $readmore; ?>
					<?php echo $loading_icon; ?>
				<?php else: ?>
					<?php echo $thumbnail; ?>
					<?php echo $title; ?>
					<?php echo $excerpt; ?>
					<?php echo $readmore; ?>
					<?php echo $loading_icon; ?>
				<?php endif ?>
			<?php if ($type == "multi"): ?>
				</li>
			<?php else: ?>
				</div>
			<?php endif ?>

			<div id="wd-modal-container-<?php the_ID(); ?>"></div>
		<?php
		return ob_get_clean();
	}
}
?>