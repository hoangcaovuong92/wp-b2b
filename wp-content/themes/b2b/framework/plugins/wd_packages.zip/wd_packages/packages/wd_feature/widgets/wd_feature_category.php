<?php
if( !class_exists( 'wd_widget_feature_category' ) ) {
	class wd_widget_feature_category extends WD_Widgets_Fields {
        public function __construct() {
			$this->widget_init();
		}
		
		public function init_settings(){
			$this->list_widget_field_default = array(
                'id'						=> 0,
                'columns'					=> 4,
                'columns_tablet'			=> 2,
                'columns_mobile'			=> 1,
                'number_feature'			=> 4,
                'sort'						=> 'ASC',
                'order_by'					=> 'date', 
                'text_align'				=> 'text-left', 
                'show_icon_font_thumbnail'	=> 'show-icon',
                'icon_size'					=> 'fa-1x',
                'style_font'				=> 'sync-with-title',
                'image_size'				=> 'full',
                'title'						=> '1',
                'show_excerpt'				=> '1',
                'number_word'				=> '10',
                'readmore'					=> '1',
                'open_link_with'			=> 'modal',
                'readmore_text'				=> 'Read More',
                'is_slider'					=> '0',
                'show_nav'					=> '1',
                'auto_play'					=> '1',
                'style_class'				=> 'style-1',
                'class'						=> '',
            );
			$this->widget_name = esc_html__('WD - Feature Category','wd_package');
			$this->widget_desc = esc_html__('Display feature by category and slider...','wd_package');
			$this->widget_slug = 'widget_feature_category';
			$this->callback = 'wd_feature_category_function';
		}

		public function form( $instance ) {
	       	foreach ($this->list_widget_field_default as $key => $value) {
	    		${$key}   	= isset( $instance[$key] ) ? esc_attr( $instance[$key] ) : $value;
	    	}

	    	$id_arr 		= wd_get_list_category('wd_feature_categories');
	    	$columns_arr 	= wd_get_list_tvgiao_columns();
	    	$sort_arr 		= wd_get_sort_by_values();
	    	$order_by_arr 	= wd_get_order_by_values();
	    	$text_align_arr = wd_get_list_text_align_bootstrap();

	    	$show_icon_font_thumbnail_arr = array(
	    		'show-icon' 	=> 'Show Icon Font',
				'show-image' 	=> 'Show Thumbnail',
				'hide' 			=> 'Hide Icon & Thumbnail',
	    	);
            $icon_size_arr      = wd_get_list_awesome_font_size();
            $style_font_arr     = array(
                    'sync-with-title'       => 'Sync with title',
                    'separate-from-title'   => 'Separate from title'
                );

	    	$image_size_arr 	= wd_get_list_image_size();
	    	$title_arr 			= wd_get_list_tvgiao_boolean();
	    	$show_excerpt_arr 	= wd_get_list_tvgiao_boolean();
	    	$readmore_arr 		= wd_get_list_tvgiao_boolean();
	    	$open_link_with_arr = array(
				'modal' => 'Modal Popup',
				'link' 	=> 'Feature Link',
			);
			$is_slider_arr 		= wd_get_list_tvgiao_boolean();
            $show_nav_arr 		= wd_get_list_tvgiao_boolean();
            $auto_play_arr 		= wd_get_list_tvgiao_boolean();
            $style_class_arr 	= wd_get_list_style_class(2);
            
            $this->select_field(
                esc_html__( 'Select Feature Category:', 'wd_package' ), 
                $this->get_field_name( 'id' ), 
                $this->get_field_id( 'id' ), 
                $id_arr, 
                $id
            );

            $this->select_field(
                esc_html__( 'Columns:', 'wd_package' ), 
                $this->get_field_name( 'columns' ), 
                $this->get_field_id( 'columns' ), 
                $columns_arr,
                $columns
            ); 
            $this->hidden_field(
                $this->get_field_name( 'columns_tablet' ),
                $this->get_field_id( 'columns_tablet' ),
                $columns_tablet
            );

            $this->hidden_field(
                $this->get_field_name( 'columns_mobile' ),
                $this->get_field_id( 'columns_mobile' ),
                $columns_mobile
            );

            $this->text_field(
    			esc_html__( 'Number Of Feature:', 'wd_package' ), 
    			$this->get_field_name( 'number_feature' ),
    			$this->get_field_id( 'number_feature' ),
    			$number_feature, 
    			esc_html__("", 'wd_package')
    		);

    		$this->select_field(
                esc_html__( 'Sort By:', 'wd_package' ), 
                $this->get_field_name( 'sort' ), 
                $this->get_field_id( 'sort' ), 
                $sort_arr, 
                $sort
            );

            $this->select_field(
                esc_html__( 'Order By:', 'wd_package' ), 
                $this->get_field_name( 'order_by' ), 
                $this->get_field_id( 'order_by' ), 
                $order_by_arr, 
                $order_by
            );

            $this->select_field(
                esc_html__( 'Text Align:', 'wd_package' ), 
                $this->get_field_name( 'text_align' ), 
                $this->get_field_id( 'text_align' ), 
                $text_align_arr, 
                $text_align
            );


            $this->select_field(
                esc_html__( 'Show Thumbnail Or Icon Font:', 'wd_package' ), 
                $this->get_field_name( 'show_icon_font_thumbnail' ), 
                $this->get_field_id( 'show_icon_font_thumbnail' ), 
                $show_icon_font_thumbnail_arr, 
                $show_icon_font_thumbnail,
                esc_html__( 'Customize icon font class and thumbnails in the feature edit page.', 'wd_package' )
            );

            $this->select_field(
                esc_html__( 'Icon Size (Icon Setting):', 'wd_package' ), 
                $this->get_field_name( 'icon_size' ), 
                $this->get_field_id( 'icon_size' ), 
                $icon_size_arr, 
                $icon_size
            );

            $this->select_field(
                esc_html__( 'Style Font Icon (Icon Setting):', 'wd_package' ), 
                $this->get_field_name( 'style_font' ), 
                $this->get_field_id( 'style_font' ), 
                $style_font_arr, 
                $style_font
            );


        	$this->select_field(
                esc_html__( 'Thumbnail Size (Image Setting):', 'wd_package' ), 
                $this->get_field_name( 'image_size' ), 
                $this->get_field_id( 'image_size' ), 
                $image_size_arr, 
                $image_size
            );

            $this->select_field(
                esc_html__( 'Show feature title:', 'wd_package' ), 
                $this->get_field_name( 'title' ), 
                $this->get_field_id( 'title' ), 
                $title_arr, 
                $title
            );

            $this->select_field(
                esc_html__( 'Show excerpt:', 'wd_package' ), 
                $this->get_field_name( 'show_excerpt' ), 
                $this->get_field_id( 'show_excerpt' ), 
                $show_excerpt_arr, 
                $show_excerpt
            );

            $this->text_field(
    			esc_html__( 'Number Word Excerpt:', 'wd_package' ), 
    			$this->get_field_name( 'number_word' ),
    			$this->get_field_id( 'number_word' ),
    			$number_word, 
    			esc_html__("Set -1 to show full excerpt", 'wd_package')
    		);

    		$this->select_field(
                esc_html__( 'Show Readmore:', 'wd_package' ), 
                $this->get_field_name( 'readmore' ), 
                $this->get_field_id( 'readmore' ), 
                $readmore_arr, 
                $readmore
            );

            $this->select_field(
                esc_html__( 'Open Link With (Readmore Setting):', 'wd_package' ), 
                $this->get_field_name( 'open_link_with' ), 
                $this->get_field_id( 'open_link_with' ), 
                $open_link_with_arr, 
                $open_link_with
            );

    		$this->text_field(
    			esc_html__( 'Readmore Text (Readmore Setting):', 'wd_package' ), 
    			$this->get_field_name( 'readmore_text' ),
    			$this->get_field_id( 'readmore_text' ),
    			$readmore_text, 
    			esc_html__("Leave blank if you want to use single feature read more text setting.", 'wd_package')
    		);

    		$this->select_field(
                esc_html__( 'Is Slider:', 'wd_package' ), 
                $this->get_field_name( 'is_slider' ), 
                $this->get_field_id( 'is_slider' ), 
                $is_slider_arr, 
                $is_slider
            );
            $this->select_field(
                esc_html__( 'Show Nav:', 'wd_package' ), 
                $this->get_field_name( 'show_nav' ), 
                $this->get_field_id( 'show_nav' ), 
                $show_nav_arr, 
                $show_nav
            ); 
            $this->select_field(
                esc_html__( 'Auto Play:', 'wd_package' ), 
                $this->get_field_name( 'auto_play' ), 
                $this->get_field_id( 'auto_play' ), 
                $auto_play_arr, 
                $auto_play
            ); 

    		$this->select_field(
                esc_html__( 'Style:', 'wd_package' ), 
                $this->get_field_name( 'style_class' ), 
                $this->get_field_id( 'style_class' ), 
                $style_class_arr, 
                $style_class
            );

    		$this->text_field(
    			esc_html__( 'Extra class name:', 'wd_package' ), 
    			$this->get_field_name( 'class' ),
    			$this->get_field_id( 'class' ),
    			$class, 
    			esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package')
    		);
	    }
	}
	function wp_widget_register_widget_feature_category() {
		register_widget( 'wd_widget_feature_category' );
	}
	add_action( 'widgets_init', 'wp_widget_register_widget_feature_category' );
}