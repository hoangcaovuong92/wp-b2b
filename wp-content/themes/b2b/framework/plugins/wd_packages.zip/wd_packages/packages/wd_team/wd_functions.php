<?php 
// var : $part = about, web_referemces, social, role, work_experiences, skill;
if( !function_exists('wd_team_member_get_meta_data') ){
	function wd_team_member_get_meta_data($part = 'about') { 
		global $post;
		$meta_data = unserialize(get_post_meta( get_the_ID(), 'wd_team_meta_data', true ));
		return !empty($meta_data['wd_team_'.$part]) ? $meta_data['wd_team_'.$part] : false;
	}
} 

if( !function_exists('wd_team_member_get_part_about') ){
	function wd_team_member_get_part_about($args = array()) { 
		global $post;
		$main_key 	= 'about';
		if (!wd_team_member_get_meta_data($main_key)) return;
		$main_data 	= wd_team_member_get_meta_data($main_key);

		$role_key 	= 'role';
		$role_data 	= wd_team_member_get_meta_data($role_key);

		$role_key 	= 'role';
		$role_data 	= wd_team_member_get_meta_data($role_key);

		$name 		= esc_html(get_the_title($post->ID));

		//Setting
		$default_args = array(
			'short_about' 	=> '0',
			'show_label' 	=> '1',
			'role'			=> '1',
			'name'			=> '1',
			'address'		=> '1',
			'city'			=> '1',
			'email'			=> '1',
			'website'		=> '0',
			'skype'			=> '1',
			'phone'			=> '1',
			'social'		=> '0',
		);
		$args 		= wp_parse_args( $args, $default_args );

		$address 	= $main_data['address'];
		if ($args['address']) {
			if ($args['city']) {
				$address 	= !empty($main_data['city']) ? $address. ', ' . $main_data['city'] : $address;
			}
		}
		$address 	= ($args['short_about'] && $args['city'] && !empty($main_data['city'])) ? $main_data['city'] : $address;

		ob_start();	?>
			<div class="wd-team-member-about">
				<?php if ($args['name']): ?>
					<div class="wd-team-member-name">
						<?php echo $args['show_label'] && !$args['short_about'] ? esc_html__('Full name: ', 'wd_package') : ''; ?> <?php echo esc_attr($name); ?>
					</div>
				<?php endif ?>

				<?php if ($args['role'] && $args['short_about']): ?>
					<?php if (count($role_data) > 0): ?>
						<div class="wd-team-member-role">
							<?php echo $args['show_label'] && !$args['short_about'] ? esc_html__('Role: ', 'wd_package') : ''; ?>
							<ul>
								<?php foreach ($role_data as $role): ?>
									<li><?php echo $role['role']; ?> - <a href="<?php echo esc_url($role['company_url']); ?>"><?php echo $role['company_name']; ?></a></li>
								<?php endforeach ?>
							</ul>
						</div>
					<?php endif ?>
				<?php endif ?>

				<?php if ($args['address']): ?>
					<div class="wd-team-member-address">
						<?php echo $args['show_label'] && !$args['short_about'] ? esc_html__('Address: ', 'wd_package') : ''; ?> <?php echo $address; ?>
					</div>
				<?php endif ?>

				<?php if ($args['email'] && !$args['short_about']): ?>
					<div class="wd-team-member-email">
						<?php echo $args['show_label'] ? esc_html__('Email: ', 'wd_package') : ''; ?> <?php echo $main_data['email']; ?>
					</div>
				<?php endif ?>

				<?php if ($args['website'] && !$args['short_about']): ?>
					<?php echo wd_team_member_get_part_website(array('show_label' => $args['show_label'])); ?>
				<?php endif ?>

				<?php if ($args['skype'] && !$args['short_about']): ?>
					<div class="wd-team-member-skype">
						<?php echo $args['show_label'] ? esc_html__('Skype: ', 'wd_package') : ''; ?> <?php echo $main_data['skype']; ?>
					</div>
				<?php endif ?>

				<?php if ($args['phone'] && !$args['short_about']): ?>
					<div class="wd-team-member-phone">
						<?php echo $args['show_label'] ? esc_html__('Phone: ', 'wd_package') : ''; ?> <?php echo $main_data['phone']; ?>
					</div>
				<?php endif ?>

				<?php if ($args['social'] && !$args['short_about']): ?>
					<?php echo wd_team_member_get_part_social(array('show_label' => $args['show_label'])); ?>
				<?php endif ?>
				
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_count_view') ){
	function wd_team_member_get_part_count_view($args = array()) { 
		global $post;
		//Setting
		$default_args = array(
			'show_label'		=> '1', 
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);
		ob_start(); ?>
			<div class="wd-team-member-view-count">
				<?php echo wd_team_member_get_project_view() ? wd_team_member_get_project_view() : '0'; ?>
				<?php echo $show_label ? '<span>'.esc_html__( 'Project View', 'wd_package' ).'</span>' : ''; ?>
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_website') ){
	function wd_team_member_get_part_website($args = array()) { 
		global $post;
		$main_key 		= 'web_referemces';
		if (!wd_team_member_get_meta_data($main_key)) return;
		$main_data 		= wd_team_member_get_meta_data($main_key);
		$display_name 	= !empty($main_data['web_name']) ? $main_data['web_name'] : $main_data['website'];
		$url 			= !empty($main_data['url']) ? $main_data['url'] : '#';

		//Setting
		$default_args = array(
			'show_label'		=> '0', 
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);
		ob_start(); ?>
			<div class="wd-team-member-website">
				<?php echo $show_label ? esc_html__('Website: ', 'wd_package') : ''; ?> <a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo esc_html($display_name); ?></a>
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_thumbnail') ){
	function wd_team_member_get_part_thumbnail($image_size = 'wd-team-member-image-size-1') { 
		global $post;
		ob_start(); ?>
			<div class="wd-team-member-thumbnail">
				<a href="<?php the_permalink(); ?>" class="image" title="<?php echo esc_attr(get_the_title()); ?>" ><?php the_post_thumbnail($image_size, array( 'alt' => esc_attr(get_the_title()), 'title' => esc_attr(get_the_title()) )); ?><div class="thumbnail-effect"></div> </a>
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_banner_image_url') ){
	function wd_team_member_get_part_banner_image_url() { 
		global $post;
		$_layout_config = wd_get_custom_layout($post->ID);
		$image_url 		= !empty($_layout_config['custom_image']) ? wp_get_attachment_url( $_layout_config['custom_image'] ) : '';
		return $image_url;
	}
}

if( !function_exists('wd_team_member_get_project_view') ){
	function wd_team_member_get_project_view() { 
		global $post;
		$main_key 	= 'project';
		if (!wd_team_member_get_meta_data($main_key) || !post_type_exists('portfolio')) return;
		$main_data 	= wd_team_member_get_meta_data($main_key);
		$random_id  = 'wd-team-member-project-'.mt_rand();
		$count 		= 0;
		if (count($main_data) > 0){
			foreach ($main_data as $project_id) {
				$count += wd_get_post_views( $project_id, false, false );
			}
		}
		return $count;
	}
}

if( !function_exists('wd_team_member_get_part_description') ){
	function wd_team_member_get_part_description($number_word = '-1') { 
		global $post;
		$content 	= ( $number_word > 0 ) ? wp_trim_words($post->post_content, $number_word, '...') : $post->post_content;
		ob_start(); ?>
			<div class="wd-team-member-description">
				<?php echo esc_attr($content); ?>
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_social') ){
	function wd_team_member_get_part_social($args = array()) { 
		global $post;
		$main_key 		= 'social';
		if (!wd_team_member_get_meta_data($main_key)) return;
		$main_data 		= wd_team_member_get_meta_data($main_key);
		extract($main_data);
		$list_social 	= array('facebook', 'instagram', 'twitter', 'vimeo', 'rss', 'google', 'linkedin');

		//Setting
		$default_args = array(
			'show_label'		=> '0', 
			'show_title'		=> '0', 
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);
		ob_start(); ?>
			<?php if (count($main_data) > 0): ?>
				<div class="wd-team-member-social">
					<?php echo $show_label ? esc_html__('On The Web: ', 'wd_package') : ''; ?> 
					<ul>
						<?php foreach ($list_social as $social): ?>
							<?php if (${$social.'_link'}): ?>
								<?php $title = ($show_title) ? $social : ''; ?>
								<li><a class="<?php echo esc_attr(${$social.'_icon'}); ?>" href="<?php echo esc_url(${$social.'_link'}); ?>" target="_blank" title="<?php echo esc_attr($social); ?>" > <?php echo esc_html($title); ?></a></li>	
							<?php endif ?>
						<?php endforeach ?>
					</ul>
				</div>
			<?php endif ?>
		<?php
		return ob_get_clean();
	}
}

if( !function_exists('wd_team_member_get_part_job') ){
	function wd_team_member_get_part_job($args = array()) { 
		global $post;
		$main_key 	= 'work_experiences';
		if (!wd_team_member_get_meta_data($main_key)) return;
		$main_data 	= wd_team_member_get_meta_data($main_key);

		//Setting
		$default_args = array(
			'show_position'		=> '1', 
			'show_time'			=> '1', 
			'show_company'		=> '1', 
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);
		ob_start(); ?>
			<div class="wd-team-member-job">
				<?php if (count($main_data) > 0): ?>
					<ul>
						<?php foreach ($main_data as $job): ?>
								<li>
									<?php if ($show_position): ?>
										<div class="wd-team-member-job-position"><?php echo esc_html($job['position']); ?></div>
									<?php endif ?>

									<?php if ($show_time): ?>
										<div class="wd-team-member-job-time"><?php printf(__('%s | %s', 'wd_package'), $job['date_start'], $job['date_end'] ); ?></div>
									<?php endif ?>

									<?php if ($show_company): ?>
										<div class="wd-team-member-job-company">
											<a href="<?php echo esc_url($job['company_url']); ?>" target="_blank" title="<?php echo esc_attr($job['company_name']); ?>" ><?php echo esc_html($job['company_name']); ?></a>
										</div>
									<?php endif ?>
								</li>	
						<?php endforeach ?>
					</ul>
				<?php endif ?>
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_skill') ){
	function wd_team_member_get_part_skill($args = array()) { 
		global $post;
		$main_key 	= 'skill';
		if (!wd_team_member_get_meta_data($main_key)) return;
		$main_data 	= wd_team_member_get_meta_data($main_key);

		//Setting
		$default_args = array(
			'style'			=> 'bar', //bar or list
			'title_color'	=> '#d35400', //bar or list
			'bar_color'		=> '#e67e22', //bar or list
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);

		ob_start(); ?>
			<div class="wd-team-member-skill">
				<?php if (count($main_data) > 0): ?>
					<?php if ($style == 'bar'): ?>
						<?php foreach ($main_data as $skill): ?>
							<div class="wd-skillbar clearfix" data-percent="<?php echo $skill['level'].'%'; ?>">
								<div class="wd-skillbar-title" style="background: <?php echo $title_color; ?>;"><span><?php echo $skill['name']; ?></span></div>
								<div class="wd-skillbar-bar" style="background: <?php echo $bar_color; ?>;"></div>
								<div class="wd-skill-bar-percent"><?php echo $skill['level'].'%'; ?></div>
							</div> <!-- End wd-Skill Bar -->	
						<?php endforeach ?>
					<?php elseif ($style == 'list'): ?>
						<?php $list_skill_name = array(); ?>
						<?php foreach ($main_data as $skill): ?>
							<?php $list_skill_name[] = $skill['name']; ?>
						<?php endforeach ?>
						<?php if (count($list_skill_name) > 0): ?>
							<?php echo implode(', ', $list_skill_name); ?>
						<?php endif ?>
					<?php endif ?>
				<?php endif ?>
			</div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_part_project') ){
	function wd_team_member_get_part_project($args = array()) { 
		global $post;
		$main_key 	= 'project';
		if (!wd_team_member_get_meta_data($main_key) || !post_type_exists('portfolio')) return;
		$main_data 	= wd_team_member_get_meta_data($main_key);
		$random_id  = 'wd-team-member-project-'.mt_rand();

		//Setting
		$default_args = array(
			'columns'        	=> '4',
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);

		ob_start(); ?>
			<div class="wd-team-member-project wd-columns-<?php echo esc_attr($columns); ?>">
				<?php if (count($main_data) > 0): ?>
					<?php 
					$args 			= array(
						'post_type'      => 'portfolio',
						'post__in'		 => $main_data,
					);
					$team_project 	= new WP_Query( $args );
					?>
					<?php if ( $team_project->have_posts() ) : ?>
						<ul>
							<?php while ( $team_project->have_posts() ) : $team_project->the_post(); ?>
								<?php echo wd_team_member_get_project_content(array('random_id' => $random_id)); ?>
							<?php endwhile; ?>
						</ul>
					<?php endif ?>
					<?php wp_reset_query(); ?>
				<?php endif ?>
			</div>
			<div class="clear clearfix"></div>
		<?php
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_project_content') ){
	function wd_team_member_get_project_content($args = array()) { 
		global $post;

		//Setting
		$default_args = array(
			'random_id'        	=> 'wd-team-member-project-'.mt_rand(),
			'image_size'		=> 'wd-portfolio-image-size-1',
			'padding'			=> '15',
			'show_image'		=> '1',
			'show_title'		=> '1',
			'show_category'		=> '1',
			'show_desc'			=> '0',
			'number_word'		=> '20',
			'show_meta'			=> '1',
			'show_readmore'		=> '0',
		);
		$args = wp_parse_args( $args, $default_args );
		extract($args);

		if ( has_post_thumbnail() && get_the_post_thumbnail() ) {
			$thumbnail_id 	= get_post_thumbnail_id( get_the_ID() );
			$thumbnail_src 	= wp_get_attachment_image_src( $thumbnail_id, 'full');

			//$light_box_url = trim( WD_Portfolio::wd_portfolio_get_meta( 'wd-portfolio' ) );
			//if ( strlen( $light_box_url ) <= 0 ) {
			$light_box_url = $thumbnail_src[0];
			//}

			$thumbnail_img = get_the_post_thumbnail( null, $image_size );
		} else {
			$light_box_url = WDP_IMAGE . '/600x364.png';
			$thumbnail_img = '<img width="600" height="364" src="' . $light_box_url . '" class="attachment-portfolio_image size-portfolio_image wp-post-image" alt="">';
		}
		$light_box_class = WD_Portfolio::wd_portfolio_get_filetype( $light_box_url );

		$style_padding_item = ($padding) ? 'padding:'.$padding.'px;' : '' ;
		?>
		<li class="wd-team-member-project-item-wrap <?php wd_portfolio_class_slug_category(); ?>" style="<?php echo esc_attr( $style_padding_item ); ?>">
			<div class="wd-team-member-project-item-thumbnail">
				<div class="wd-team-member-project-item-thumbnail-image">
					<a class="zoom-gallery wd-fancybox-thumbs <?php echo esc_attr( $light_box_class ); ?>"
					   data-toggle="tooltip"
					   data-fancybox-group="<?php echo $random_id; ?>"
					   title="<?php _e( 'Quick View', 'wd_package' ) ?>"
					   data-caption="<?php the_title(); ?>"
					   href="<?php echo esc_url( $light_box_url ); ?>" >
					
					   	<?php if ($show_image): ?><?php echo $thumbnail_img; ?><?php endif ?>
								   	</a>
				</div>
			   	<div class="wd-team-member-project-item-permarlink">
			   		<a class="zoom-gallery wd-fancybox-thumbs <?php echo esc_attr( $light_box_class ); ?>"
						   data-toggle="tooltip"
						   data-fancybox-group="<?php echo $random_id.'-2'; ?>"
						   title="<?php _e( 'Quick View', 'wd_package' ) ?>"
						   data-caption="<?php the_title(); ?>"
						   href="<?php echo esc_url( $light_box_url ); ?>" ></a>
			   		<a class="wd-team-member-detail-link-icon" href="<?php the_permalink(); ?>"></a>
			   	</div>
		   	</div>

			<div class="hwd-team-member-project-item-content">
				<?php if ($show_category): ?>
					<div class="wd-team-member-project-category">
						<?php $post_categories = get_the_term_list( get_the_ID(), 'wd-portfolio-category', '', ' , ', '' ); ?>
						<?php echo( $post_categories ); ?>
					</div><!-- .wd-category-portfolio -->
				<?php endif ?>

				<?php if ($show_title): ?>
					<div class="wd-team-member-project-title">
						<h2 class="wd-heading-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>
					</div>
				<?php endif ?>

				<?php if ($show_desc): ?>
					<div class="wd-team-member-project-desc">
						<?php $content 	= ( $number_word > 0 ) ? wp_trim_words($post->post_content, $number_word, '...') : $post->post_content; ?>
						<?php echo esc_attr($content); ?>
					</div>
				<?php endif ?>

				<?php if ($show_meta): ?>
					<div class="wd-team-member-project-meta">
						<span class="wd-team-member-project-view-number"><?php do_action('wd_get_post_views'); ?></span>
						<span class="wd-team-member-project-view-like"><?php do_action('wd_post_like'); ?></span>
					</div>
				<?php endif ?>
				
				<?php if ($show_readmore): ?>
					<div class="wd-team-member-project-readmore">
						<a class="link-gallery"
						   data-toggle="tooltip"
						   title="<?php _e( "View Details", 'wd_package' ); ?>"
						   href="<?php the_permalink(); ?>"><?php esc_html_e( 'Readmore', 'wd_package' ); ?></a>
					</div><!-- .icons -->
				<?php endif ?>

			</div><!-- .hover-default -->
		</li><!-- .wd-wrap-content-item -->
		<?php
	}
}

if( !function_exists('wd_team_member_get_single_template') ){
	function wd_team_member_get_single_template($layout_style = 'style-1', $image_size = 'wd-team-member-image-size-1') { 
		global $post;
		$background_url 	= wd_team_member_get_part_banner_image_url();
		$background_style 	= $background_url != '' ? 'style="background: url('.$background_url.');"' : '';
		$class 				= 'wd-single-team-member-'.$layout_style;
		ob_start();
		?>
		<?php if ($layout_style == 'style-1'): ?>
			<section class="wd-single-team-member-about container-fluid <?php echo esc_attr( $class ); ?>" <?php echo $background_style; ?>>
					<?php echo wd_team_member_get_part_thumbnail($image_size); ?>
					<?php echo wd_team_member_get_part_about(array('short_about' => '1')); ?>
					<?php echo wd_team_member_get_part_description(); ?>
					<?php echo wd_team_member_get_part_social(); ?>
				</div>
			</section>
		<?php elseif ($layout_style == 'style-2'): ?>
			<section class="wd-single-team-member-about">
				<div class="container">
					<?php echo wd_team_member_get_part_thumbnail($image_size); ?>
					<div class="wd-single-team-member-detail">
						<?php echo wd_team_member_get_part_about(array('short_about' => '1')); ?>

						<?php 
						$content_tab 	= array();
						$content_tab[]	= array(
									'title' 	=> esc_html__( 'About Me', 'wd_package' ),
									'content' 	=> wd_team_member_get_part_about().wd_team_member_get_part_description().wd_team_member_get_part_count_view(),
								);
						$content_tab[]	= array(
									'title' 	=> esc_html__( 'Work Experience', 'wd_package' ),
									'content' 	=> wd_team_member_get_part_job(),
								);
						$content_tab[]	= array(
									'title' 	=> esc_html__( 'Skill', 'wd_package' ),
									'content' 	=> wd_team_member_get_part_skill(),
								);
						echo wd_tab_bootstrap($content_tab); ?>
					</div>
				</div>
			</section>
		<?php elseif ($layout_style == 'style-3'): ?>
			<section class="wd-single-team-member-about container-fluid <?php echo esc_attr( $class ); ?>" <?php echo $background_style; ?>>
				<div class="container">
					<?php echo wd_team_member_get_part_thumbnail($image_size); ?>
					<?php echo wd_team_member_get_part_about(array('short_about' => '1')); ?>
					<?php echo wd_team_member_get_part_count_view(); ?>
				</div>
			</section>
		<?php endif ?>
		<?php 
		return ob_get_clean();
	}
} 

if( !function_exists('wd_team_member_get_loop_template') ){
	function wd_team_member_get_loop_template($layout_style = 'style-1', $is_slider = false, $padding = 0) { 
		global $post;
		$style_padding_item = ($padding && !$is_slider) ? 'padding:'.$padding.'px;' : '' ;
		ob_start(); ?>
			<?php if ($layout_style == 'style-1'): ?>
				<li class="wd-team-member-wrap" style="<?php echo esc_attr( $style_padding_item ); ?>">
					<div class="wd-team-member-thumbnail">
						<?php echo wd_team_member_get_part_thumbnail('wd-team-member-image-size-1'); ?>
					</div>
					<div class="wd-team-member-info">
						<?php echo wd_team_member_get_part_about(array('short_about' => '1', 'address' => '0', 'city' => '0')); ?>
						<?php echo wd_team_member_get_part_social(array('show_label' => 0)); ?>
					</div>
				</li>
			<?php elseif ($layout_style == 'style-2'): ?>
				<li class="wd-team-member-wrap" style="<?php echo esc_attr( $style_padding_item ); ?>">
					<div class="wd-team-member-thumbnail">
						<?php echo wd_team_member_get_part_thumbnail('wd-team-member-image-size-1'); ?>
					</div>
					<div class="wd-team-member-info">
						<?php echo wd_team_member_get_part_about(array('short_about' => '1', 'address' => '0', 'city' => '0')); ?>
						<?php echo wd_team_member_get_part_social(array('show_label' => 0)); ?>
					</div>
				</li>
			<?php elseif ($layout_style == 'style-3'): ?>
				<li class="wd-team-member-wrap" style="<?php echo esc_attr( $style_padding_item ); ?>">
					<div class="wd-team-member-thumbnail">
						<?php echo wd_team_member_get_part_thumbnail('wd-team-member-image-size-1'); ?>
					</div>
					<div class="wd-team-member-info">
						<?php echo wd_team_member_get_part_about(array('short_about' => '1', 'address' => '0', 'city' => '0')); ?>
						<?php echo wd_team_member_get_part_social(array('show_label' => 0)); ?>
					</div>
				</li>
			<?php endif ?>
		<?php 
		return ob_get_clean();
	}
} 

