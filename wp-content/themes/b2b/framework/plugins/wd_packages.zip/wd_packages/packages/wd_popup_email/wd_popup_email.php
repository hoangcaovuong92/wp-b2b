<?php 
if (!class_exists('WD_Popup_Email')) {
	class WD_Popup_Email {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->constant();
			$this->include_lybrary();
			// Actions
			add_action('wp_enqueue_scripts', array( $this, 'enqueue_script'));
			add_action('wd_hook_footer_init_action', array($this, 'email_subscribe_popup_content'), 20);
	    }

        /*-----------------------------------------------------------------------------------*/
		/* Class Functions */
		/*-----------------------------------------------------------------------------------*/
		protected function constant(){
			define('WDPE_BASE'		,   plugin_dir_path( __FILE__ )		);
			define('WDPE_BASE_URI'	,   plugins_url( '', __FILE__ )		);
			define('WDPE_JS'		, 	WDPE_BASE_URI . '/assets/js'	);
			define('WDPE_CSS'		, 	WDPE_BASE_URI . '/assets/css'	);
		}

		// Check email subscribe popup status 
		function check_email_popup_enable() {
			$type 	= session_id() ? 'session' : 'transient'; 
			$key	= 'wd_disabled_email_popup';
			if ($type == 'transient') {
				$disabled_email_popup 	= get_transient( $key );
				$result 				= ($disabled_email_popup === false) ? true : false;
			}else{
				if (!isset($_SESSION['wd_disabled_email_popup'])) return true;
			    $current_value 	= $_SESSION['wd_disabled_email_popup'];
			    $result 		= ($current_value < time()) ? true : false;
			}
		    return $result;
		}
		/* Email Subscribe Popup */
		function email_subscribe_popup_content(){
			/**
		     * package: email-popup
			 * var: display
			 * var: popup_only_home
			 * var: popup_mobile
			 * var: delay_time
			 * var: session_expire
			 * var: banner
			 * var: source
			 * var: custom_content
			 * var: feedburner_id
			 * var: width
			 * var: height
			 * var: title
			 * var: desc
			 * var: placeholder
			 * var: button_text
			 */
			$email_popup_package = get_option('wd-theme-options-packages', array());
			if (!count($email_popup_package) || !is_array($email_popup_package)) return;
			extract($email_popup_package['email-popup']); 
			
			if (!$display || !$this->check_email_popup_enable() || is_admin()) return;
			if ($popup_only_home && !is_home() && !is_front_page()) return;
			if (!$popup_mobile && wp_is_mobile()) return; ?>
		    <div id="wd-email-subscribe-popup" class="subscribe_widget" style="display:none;">
		    	<div id="wd-email-subscribe-content">
		    		<?php if (is_array($banner) && $banner['id']): ?>
		    			<?php $banner_url = wp_get_attachment_image_src( $banner['id'], 'wd_image_size_square_medium'); ?>
		    			<div class="wd-layout-half-width wd-email-subscribe-image">
		    				<div style="height:<?php echo esc_html($height); ?>px; background: url(<?php echo esc_url($banner_url[0]); ?>);"></div>
		    			</div>
		    			<div class="wd-layout-half-width">
		    		<?php endif ?>
						<div class="wd-email-subscribe-main-content">
			    			<div class="wd-tb-title">
				    			<div class="wd-tb-closeAjaxWindow"><button type="button" class="wd-tb-closeWindowButton"><span class="screen-reader-text"><?php esc_html_e( 'Close', 'wd_packages' ) ?></span><span class="tb-close-icon"></span></button></div>
				    		</div>

				    		<?php if ($source == 'feedburner'): ?>
				    			<?php if($title != "") : ?>
									<div class="wd-subscribe-header">
										<h2><?php echo esc_attr( $title ); ?></h2>
									</div>
								<?php endif; ?>
								<?php echo ($desc) ? '<div class="subscribe_intro_text">'.esc_html($desc).'</div>':'' ?>		
								<div class="subscribe_form">
									<form action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=<?php echo esc_attr($feedburner_id); ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
										<p class="subscribe-email"><input type="text" name="email" class="subscribe_email" value="" placeholder="<?php echo esc_html($placeholder); ?>" autocomplete="off" /></p>
										<input type="hidden" value="<?php echo esc_attr($feedburner_id);?>" name="uri"/>
										<input type="hidden" value="<?php echo get_bloginfo( 'name' );?>" name="title"/>
										<input type="hidden" name="loc" value="en_US"/>

										<button class="button" type="submit" title="Subscribe"><?php echo esc_attr($button_text); ?></button>
									</form>
								</div>
				    		<?php else: ?>
				    			<?php if($custom_content != '' && wd_is_visual_composer()): ?> 
									<?php $custom_content = stripslashes($custom_content); ?>
									<div class="wd-email-subscribe-popup-custom-content">
										<?php echo do_shortcode( "{$custom_content}" ); 	?>
									</div>
								<?php endif; ?>
				    		<?php endif ?>

				    		<p class="row">
								<label><input name="disabled" class="wd-email-subscribe-popup-disabled" data-expire="<?php echo esc_attr($session_expire); ?>" type="checkbox" data-val="true" value="true"> <?php esc_html_e( 'Dont show this again', 'wd_packages' ); ?></label>
							</p>
	    				</div>
	    			<?php if (is_array($banner) && $banner['url']): ?>
		    			</div>
		    		<?php endif ?>
		    	</div>
			</div>
		    <?php 
		}

		function include_lybrary(){
			if( file_exists(WDPE_BASE.'/wd_functions.php') ){
				require_once WDPE_BASE.'/wd_functions.php';
			}
		}

		/* Get Script accessibility */
		function email_subscribe_popup_script(){
			/**
		     * package: accessibility
			 * var: chatbox_status
			 * var: popup_email
			 * var: popup_only_home
			 * var: popup_mobile
			 * var: popup_email_width
			 * var: popup_email_height
			 * var: popup_delay_time 
			 */
			$accessibility_package = get_option('wd-theme-options-packages', array());
			if (!count($accessibility_package) || !is_array($accessibility_package)) return;
			extract($accessibility_package['accessibility']); 
	   		if (!$popup_email) return;
	   		$custom_script = '';
			ob_start(); ?>
				<?php if (!$popup_email || !$this->wd_email_popup_enable()) return; ?>
				<?php if ($popup_only_home && !is_home() && !is_front_page()) return; ?>
				<?php if (!$popup_mobile && wp_is_mobile()) return; ?>
					wd_accessibility_email_subscribe_popup(<?php echo esc_html($popup_email_width); ?>,<?php echo esc_html($popup_email_height); ?>, <?php echo esc_html($popup_delay_time); ?>);
			<?php
			$custom_script = ob_get_clean();
			return $custom_script;
		}

		function enqueue_script() {
			if ( is_admin() )
				return;
			//Style
			wp_enqueue_style( 'wd-popup-email-styles', WDPE_CSS. '/wd_style.css' );
			// Scripts
			$custom_script = $this->email_subscribe_popup_script();
			wp_enqueue_script( 'wd-popup-email-js', WDPE_JS. '/wd_scripts.js', array( 'jquery' ), false, true );
			wp_add_inline_script( 'wd-popup-email-js', $custom_script );

		}
	}

	WD_Popup_Email::get_instance();
}