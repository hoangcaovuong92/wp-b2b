//****************************************************************//
/*							Main JS								  */
//****************************************************************//
jQuery(document).ready(function($) {
	"use strict";
	wd_currency_dropdown_select()
});

//****************************************************************//
/*							FUNCTIONS							  */
//****************************************************************//
if (typeof wd_currency_dropdown_select != 'function') { 
	function wd_currency_dropdown_select(){
		var element_parrent = '.wd-currency-switcher-dropdown';
		if(jQuery(element_parrent).length > 0 ){
			jQuery(element_parrent+' .wd-currency-opiton').click(function() {
		        jQuery(element_parrent+' .wd-navUser-action--currency').html(jQuery(this).html());
		    });
		}
	}
}