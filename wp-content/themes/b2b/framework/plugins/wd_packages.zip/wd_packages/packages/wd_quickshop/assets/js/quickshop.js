/**
 * WD QuickShop
 *
 * @license commercial software
 * @copyright (c) 2017 Codespot Software JSC - WPDance.com. (http://www.wpdance.com)
 */

jQuery(document).ready(function($){
	"use strict";
	//insert quickshop popup
  	qs_prettyPhoto();
});

//****************************************************************//
/*							FUNCTIONS							  */
//****************************************************************//
if (typeof prettyPhotocallback != 'function') {
	function qs_prettyPhoto() {
		jQuery('.wd_quickshop_handler').prettyPhoto({
			deeplinking: false,
			opacity: 0.9,
			social_tools: false,
			default_width: 900,
			default_height: 500,
			theme: 'pp_woocommerce',
			changepicturecallback : prettyPhotocallback
		});
	}
}
//Pretty Photo Callback
if (typeof prettyPhotocallback != 'function') { 
	function prettyPhotocallback() {

		wd_quickshop_init();
		jQuery("div.quantity:not(.buttons_added), td.quantity:not(.buttons_added)").addClass('buttons_added');

		if (jQuery('.pp_inline form.wd-variations-form').length > 0 ) {
			jQuery('.pp_inline').find('form.wd-variations-form .variations select').change();
			if (jQuery('.pp_inline .qs-left-content').hasClass('qs-enabled-variation')) { 
				jQuery('.pp_inline').find('form.variations_form').wc_variation_form();
			}
			if (typeof wd_product_variation_product_select === "function") { 
				wd_product_variation_product_select();
			}
		}
		

		/* QuickShop thumbnail slider */
		if (typeof wd_slider_product_thumbnail === "function") {
			wd_slider_product_thumbnail('.qs-left-content .wd-single-product-thumbnails-data');
		}
		//disable link review link
		jQuery('.qs-right-content .woocommerce-review-link').on('click', function(e){
			e.preventDefault();
		})
	}
}

// quickshop init
if (typeof wd_quickshop_init != 'function') { 
	function wd_quickshop_init() {
		if (typeof wd_slick_slider_call === "function") {
			wd_set_cloud_zoom();
		}
		
		//fix bug group 0 qty, and out of stock
		jQuery('.wd_quickshop.product form button.single_add_to_cart_button').live('click',function(){
			if(jQuery('.wd_quickshop.product form table.group_table').length > 0){
				jQuery('.wd_quickshop.product').prev('ul.woocommerce-error').remove();
				temp = 0;
				jQuery('.wd_quickshop.product form table.group_table').find('input.qty').each(function(i,value){
					var td_cur = jQuery(value).closest( "td" );
					
					if(jQuery(value).val() > temp && !td_cur.next().hasClass('wd_product_out-of-stock'))
						temp = jQuery(value).val();
				});
				if(temp == 0) {
					jQuery('.wd_quickshop.product').before( $( "<ul class=\'woocommerce-error\'><li>Please choose the quantity of items you wish to add to your cart…</li></ul>" ) );
					return false;
				}	
			}
		});
	}
}