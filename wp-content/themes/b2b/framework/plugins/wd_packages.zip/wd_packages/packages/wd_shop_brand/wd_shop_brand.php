<?php
if (!class_exists('WD_Shop_Brand_Taxonomy')) {
	class WD_Shop_Brand_Taxonomy {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $taxonomy 		= 'product_brand';
		protected $arrShortcodes 	= array('brand_slider');
		protected $widget_file_name = array(
			/* filename  => classname */
			//'filter_by_brand' => 'wd_widget_product_brand_filter',
		);
		public function __construct(){
			$this->constant();
			/****************************/
			// Register BRANDS TAXONOMY
			if($this->checkPluginVC()){
				add_action('vc_before_init', array( $this, 'register_taxonomy' ) );
			}else{
				add_action('init', array( $this, 'register_taxonomy' ) );
			}

    		//Add column to taxonomy Term
    		add_filter('manage_edit-'.$this->taxonomy.'_columns', array ( $this, 'add_columns' ));
			add_filter('manage_'.$this->taxonomy.'_custom_column', array ( $this, 'add_column_content' ), 10, 3);

		 	add_action( $this->taxonomy.'_add_form_fields', array ( $this, 'add_category_image' ), 10, 2 );
		 	add_action( $this->taxonomy.'_edit_form_fields', array ( $this, 'update_category_image' ), 10, 2 );
		 	add_action( 'created_'.$this->taxonomy.'', array ( $this, 'save_category_image' ), 10, 2 );
		 	add_action( 'edited_'.$this->taxonomy.'', array ( $this, 'updated_category_image' ), 10, 2 );

			add_action('admin_enqueue_scripts',array($this,'init_admin_script'));

			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}

			//Widgets
			$this->initWidgets();
		}
		
		protected function constant(){
			define('WDPBR_BASE'			,   plugin_dir_path( __FILE__ ));
			define('WDPBR_BASE_URI'		,   plugins_url( '', __FILE__ ));
			define('WDPBR_JS'			, 	WDPBR_BASE_URI . '/assets/js'		);
			define('WDPBR_CSS'			, 	WDPBR_BASE_URI . '/assets/css'		);
			define('WDPBR_ADMIN_JS'		, 	WDPBR_BASE_URI . '/admin/js'		);
			define('WDPBR_ADMIN_CSS'	, 	WDPBR_BASE_URI . '/admin/css'		);
			define('WDPBR_ADMIN_LIB'	, 	WDPBR_BASE_URI . '/admin/libs'		);
			define('WDPBR_IMAGE'		, 	WDPBR_BASE_URI . '/images'			);
			define('WDPBR_TEMPLATE' 	, 	WDPBR_BASE . '/templates'			);
			define('WDPBR_WIDGET' 		, 	WDPBR_BASE . '/widgets'				);
		}

		/******************************** BRANDS TAXONOMY ***********************************/

		public function register_taxonomy(){
			register_taxonomy( $this->taxonomy, 'product', array(
				'hierarchical'     		=> true,
				'labels'            	=> array(
					'name' 				=> esc_html__('Brands', 'wd_package'),
					'singular_name' 	=> esc_html__('Brand', 'wd_package'),
		        	'new_item'          => esc_html__('Add New', 'wd_package' ),
		        	'edit_item'         => esc_html__('Edit Post', 'wd_package' ),
		        	'view_item'   		=> esc_html__('View Post', 'wd_package' ),
		        	'add_new_item'      => esc_html__('Add New Brand', 'wd_package' ),
		        	'menu_name'         => esc_html__( 'Brands' , 'wd_package' ),
				),
				'show_ui'           	=> true,
				'show_admin_column' 	=> true,
				'query_var'         	=> true,
				'rewrite'           	=> array( 'slug' => $this->taxonomy ),				
				'public'				=> true,
			));		
		}

		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(WDPBR_TEMPLATE."/wd_{$shortcode}.php") ){
					require_once WDPBR_TEMPLATE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(WDPBR_TEMPLATE."/wd_vc_{$visual}.php") ){
					require_once WDPBR_TEMPLATE."/wd_vc_{$visual}.php";
				}
			}
	    } 
	    protected function initWidgets(){
			foreach ($this->arrShortcodes as $widget_name) {
				if( file_exists(WDPBR_WIDGET."/wd_{$widget_name}.php") ){
					require_once WDPBR_WIDGET."/wd_{$widget_name}.php";
				}	
			}
		}

		public function add_columns($columns){
		    $new_columns = array();
			$new_columns['cb'] = $columns['cb'];
			$new_columns['logo'] = __( 'Logo', 'wd_package' );

			unset( $columns['cb'] );

			return array_merge( $new_columns, $columns );
		}

		public function add_column_content( $content, $column_name, $term_id ){
		    if ( 'logo' == $column_name ) {
		    	$image_id = get_term_meta( $term_id, 'category-image-id', true );
		        $content = '<div class="wd-logo-brand">';
		        $content .= '<img style=" max-width: 100%; height: auto;" src="'.wp_get_attachment_image_url($image_id, 'thumbnail', true).'" alt="Logo Brand">';
		        $content .= '</div>';
		    }
			return $content;
		}
		
		 /*
		  * Add a form field in the new category page
		  * @since 1.0.0
		 */
		public function add_category_image ( $taxonomy ) { ?>
			<div class="form-field term-group">
			 	<label for="category-image-id"><?php _e('Image', 'wd_package'); ?></label>
			 	<input type="hidden" id="category-image-id" name="category-image-id" class="custom_media_url" value="">
			 	<div id="category-image-wrapper"></div>
			 	<p>
			 		<input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'wd_package' ); ?>" />
			 		<input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'wd_package' ); ?>" />
			 	</p>
			</div>
			<?php
		}

		 /*
		  * Save the form field
		  * @since 1.0.0
		 */
		public function save_category_image ( $term_id, $tt_id ) {
		 	if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
		 		$image = $_POST['category-image-id'];
		 		add_term_meta( $term_id, 'category-image-id', $image, true );
		 	}
		}
		 
		 /*
		  * Edit the form field
		  * @since 1.0.0
		 */
		public function update_category_image ( $term, $taxonomy ) { ?>
		 <tr class="form-field term-group-wrap">
		 	<th scope="row">
		 		<label for="category-image-id"><?php _e( 'Image', 'wd_package' ); ?></label>
		 	</th>
		 	<td>
		 		<?php $image_id = get_term_meta( $term->term_id, 'category-image-id', true ); ?>
		 		<input type="hidden" id="category-image-id" name="category-image-id" value="<?php echo $image_id; ?>">
		 		<div id="category-image-wrapper">
		 			<?php if ( $image_id ) { ?>
		 			<?php echo wp_get_attachment_image ( $image_id, 'thumbnail' ); ?>
		 			<?php } ?>
		 		</div>
		 		<p>
		 			<input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'wd_package' ); ?>" />
		 			<input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'wd_package' ); ?>" />
		 		</p>
		 	</td>
		 </tr>
		 <?php
		}

		/*
		 * Update the form field value
		 * @since 1.0.0
		 */
		public function updated_category_image ( $term_id, $tt_id ) {
			if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
				$image = $_POST['category-image-id'];
				update_term_meta ( $term_id, 'category-image-id', $image );
			} else {
				update_term_meta ( $term_id, 'category-image-id', '' );
			}
		}


		public function init_admin_script($hook) {
			$screen = get_current_screen();
			if ($hook = 'edit-tags.php' && $this->taxonomy == $screen->taxonomy) {
				wp_enqueue_style('wd-'.$this->taxonomy.'-css', 	WDPBR_ADMIN_CSS.'/wd_admin.css');
				wp_enqueue_script( 'wd-'.$this->taxonomy.'-scripts', WDPBR_ADMIN_JS.'/wd_script.js',false,false,true);
			}
			
		}	

		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}

	}
	WD_Shop_Brand_Taxonomy::get_instance();  // Start an instance of the plugin class 
}