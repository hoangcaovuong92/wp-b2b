<?php
if (!class_exists('WD_FAQs')) {
	class WD_FAQs {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $post_type 	= 'wd_faq';
		protected $taxonomy 	= 'wd_faq_categories';
		protected $arrShortcodes = array('faq');

		public function __construct(){
			$this->constant();
			
			/****************************/
			// Register testimonials post type
			add_action('init', array($this, 'register_post_type'));

			if($this->checkPluginVC()){
				add_action('vc_before_init', array( $this, 'register_taxonomy' ) );
			}else{
				add_action('init', array( $this, 'register_taxonomy' ) );
			}
			
			add_theme_support('post-thumbnails', array($this->post_type) );

			//Change Placeholder Title Post
			add_filter( 'enter_title_here', array($this, 'change_title_text' ));
			
			add_action('admin_enqueue_scripts',array($this,'init_admin_script'));
			
			$this->init_handle();

			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}
		}
		
		protected function constant(){
			define('WDFAQ_BASE'			,   plugin_dir_path( __FILE__ ));
			define('WDFAQ_BASE_URI'		,   plugins_url( '', __FILE__ ));
			define('WDFAQ_JS'			, 	WDFAQ_BASE_URI . '/assets/js'		);
			define('WDFAQ_CSS'			, 	WDFAQ_BASE_URI . '/assets/css'		);
			define('WDFAQ_ADMIN_JS'		, 	WDFAQ_BASE_URI . '/admin/js'		);
			define('WDFAQ_ADMIN_CSS'	, 	WDFAQ_BASE_URI . '/admin/css'		);
			define('WDFAQ_ADMIN_LIB'	, 	WDFAQ_BASE_URI . '/admin/libs'		);
			define('WDFAQ_IMAGE'		, 	WDFAQ_BASE_URI . '/images'	);
			define('WDFAQ_TEMPLATE' 	, 	WDFAQ_BASE . '/templates'	);
		}

		/******************************** testimonials POST TYPE ***********************************/
		public function register_post_type(){
			if (!post_type_exists($this->post_type)) {
				register_post_type($this->post_type, array(
					'exclude_from_search' 	=> true, 
					'labels' 				=> array(
		                'name' 				=> _x('WD FAQs', 'post type general name','wd_package'),
		                'singular_name' 	=> _x('WD FAQs', 'post type singular name','wd_package'),
		                'add_new' 			=> _x('Add FAQs', 'FAQs','wd_package'),
		                'add_new_item' 			=> sprintf( __( 'Add New %s', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
						'edit_item' 			=> sprintf( __( 'Edit %s', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
						'new_item' 				=> sprintf( __( 'New %s', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
						'all_items' 			=> sprintf( __( 'All %s', 'wd_package' ), __( 'FAQss', 'wd_package' ) ),
						'view_item' 			=> sprintf( __( 'View %s', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
						'search_items' 			=> sprintf( __( 'Search %a', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
						'not_found' 			=>  sprintf( __( 'No %s Found', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
						'not_found_in_trash' 	=> sprintf( __( 'No %s Found In Trash', 'wd_package' ), __( 'FAQs', 'wd_package' ) ),
		                'parent_item_colon' => '',
		                'menu_name' 		=> __('WD FAQs','wd_package'),
					),
					'singular_label' 		=> __('WD FAQs','wd_package'),
					'taxonomies' 			=> array($this->taxonomy),
					'public' 				=> true,
					'has_archive' 			=> false,
					'supports' 			 	=>  array('title','editor','thumbnail'),
					'has_archive' 			=> false,
					'rewrite' 				=>  array('slug'  =>  $this->post_type, 'with_front' =>  true),
					'show_in_nav_menus' 	=> false,
					'menu_icon'				=> 'dashicons-flag',
					'menu_position'			=> 58,
				));	
			}
		}

		public function register_taxonomy(){
			register_taxonomy( $this->taxonomy, $this->post_type, array(
				'hierarchical'     		=> true,
				'labels'            	=> array(
					'name' 				=> esc_html__('Categories FAQs', 'wd_package'),
					'singular_name' 	=> esc_html__('Category FAQs', 'wd_package'),
	            	'new_item'          => esc_html__('Add New', 'wd_package' ),
	            	'edit_item'         => esc_html__('Edit Post', 'wd_package' ),
	            	'view_item'   		=> esc_html__('View Post', 'wd_package' ),
	            	'add_new_item'      => esc_html__('Add New Category FAQs', 'wd_package' ),
	            	'menu_name'         => esc_html__( 'Categories FAQs' , 'wd_package' ),
				),
				'show_ui'           	=> true,
				'show_admin_column' 	=> true,
				'query_var'         	=> true,
				'rewrite'           	=> array( 'slug' => $this->taxonomy ),				
				'public'				=> true,
			));	
		}


		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(WDFAQ_TEMPLATE."/wd_{$shortcode}.php") ){
					require_once WDFAQ_TEMPLATE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(WDFAQ_TEMPLATE."/wd_vc_{$visual}.php") ){
					require_once WDFAQ_TEMPLATE."/wd_vc_{$visual}.php";
				}
			}
	    }

	    public function change_title_text( $title ){
		    $screen = get_current_screen();
		  
		    if  ( $this->post_type == $screen->post_type ) {
		        $title = esc_html__("Enter FAQs name here", 'wd_package' );
		    }
		    return $title;
		}

	    protected function init_handle(){
			//add_image_size('wd-pricing_table-thumb',400,400,true);  
		}	
		
		public function init_admin_script($hook) {
			$screen = get_current_screen();
			if ($hook = 'post.php' && $this->post_type == $screen->post_type) {
				wp_enqueue_style('wd-testimonials-admin-custom-css', 	WDFAQ_ADMIN_CSS.'/wd_admin.css');
				wp_enqueue_script( 'wd-testimonials-scripts',		 	WDFAQ_ADMIN_JS.'/wd_script.js',false,false,true);
			}
			
		}	
		
		
		public function init_script(){
			wp_enqueue_style('wd-pricing_table-custom-css', 	WDFAQ_CSS.'/wd_custom.css');	
			wp_enqueue_script( 'wd-pricing_table-scripts',	WDFAQ_JS.'/wd_ajax.js',false,false,true);
		}


		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}

	}
	WD_FAQs::get_instance();  // Start an instance of the plugin class 
}