<?php
/**
 * Shortcode: wd_brand_slider
 */

if (!function_exists('wd_brand_slider_function')) {
	function wd_brand_slider_function($atts) {
		extract(shortcode_atts(array(
			'source'		=> '1',
			'brands'		=> '',
			'image_url'		=> '',
			'image_size'	=> 'full',
			'columns'		=> '5',
			'columns_tablet' => 2,
			'columns_mobile' => 1,
			'is_slider'		=> '1',
			'show_nav'		=> '1',
			'auto_play'		=> '1',
			'class' 		=> ''
		), $atts));
		
		$array_data = array();
		if ($source == '1') {
			if ($brands != -1 && $brands != 0 && $brands != '') {
				$brand_terms = get_terms( array(
				    'taxonomy' 		=> 'product_brand',
				    'hide_empty' 	=> false,
				    'include'		=> explode(',', $brands),
				) );
			}else{
				$brand_terms = get_terms( array(
				    'taxonomy' 		=> 'product_brand',
				    'hide_empty' 	=> false,
				) );
			}
			//List taxonomy slug
			if (count($brand_terms) > 0 && !is_wp_error( $brand_terms )) {
				foreach ($brand_terms as $brand) {
					$array_data[$brand->term_id] = $brand->slug;
				}
			}
		}else{
			//List attachment image ID
			$array_data = explode(',',$image_url);
		}

		$image_list 	= array();
		if (!$array_data) {
			return;
		}else{

			foreach ($array_data as $key => $value) {
				if ($source == '1'  && wd_is_woocommerce()) {
					$image_id 		= get_term_meta( $key, 'category-image-id', true );
					$shop_url 		= (get_permalink( wc_get_page_id( 'shop' ) ));
					$brand_url 		= add_query_arg( array('product_brand' => $value), $shop_url );
					$brand_image 	= wp_get_attachment_image($image_id, $image_size);
				}else{
					$brand_url 		= '#';
					$brand_image 	= wp_get_attachment_image($value, $image_size);
				}
				$image_list[] 	= array(
					'url'	=> $brand_url,
					'image'	=> ($brand_image) ? $brand_image : '<img src="'.SC_IMAGE.'/logo.png" alt="'.esc_html__('Brand Icon Default', 'wd_package').'" title="'.esc_html__('Brand Icon Default', 'wd_package').'" />',
				);
			}
		}

		if ($is_slider) {
			$wrap_class = '';
			$list_class	= 'wd-slider-wrap wd-slider-wrap--brand';
			$slider_options = json_encode(array(
				'slider_type' => 'owl',
				'column_desktop' => esc_attr($columns),
				'column_tablet' => esc_attr($columns_tablet),
				'column_mobile' => esc_attr($columns_mobile),
				'arrows' => $show_nav ? true : false,
				'autoplay' => $auto_play ? true : false,
			));
		}else{
			$wrap_class = ($is_slider == '0') ? 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile : '';
			$list_class	= 'wd-columns-list-item';
			$slider_options	= '';
		}

		ob_start(); ?>
			<div class="wd-shortcode-brand <?php echo esc_attr( $wrap_class ); ?> <?php echo esc_attr($class); ?> <?php echo esc_attr($columns_brand); ?>">
				<ul class="wd-brand-item-list <?php echo esc_attr( $list_class ); ?>" 
					data-slider-options='<?php echo esc_attr( $slider_options ); ?>'>
					<?php foreach($image_list as $_image){ ?>
						<li class="wd-brand-item">
							<a href="<?php echo esc_url($_image['url']); ?>" class="wd-brand-url"><?php echo $_image['image']; ?></a>
						</li>
					<?php } ?>

				</ul>
			</div>
		<?php
		$output = ob_get_clean();
		wp_reset_postdata();
		return $output;
	}
}
add_shortcode('wd_brand_slider', 'wd_brand_slider_function');
?>