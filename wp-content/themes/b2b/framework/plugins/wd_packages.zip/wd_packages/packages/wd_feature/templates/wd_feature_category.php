<?php
/**
 * Shortcode: wd_feature_category
 */
if(!function_exists('wd_feature_category_function')){
	function wd_feature_category_function($atts){
		$atts = shortcode_atts(array(
			'id'						=> 0,
			'columns'					=> 4,
			'columns_tablet'			=> 2,
			'columns_mobile'			=> 1,
			'number_feature'			=> 4,
			'sort'						=> 'ASC',
			'order_by'					=> 'date', 
			'text_align'				=> 'text-left', 
			'show_icon_font_thumbnail'	=> 'show-icon',
			'icon_size'					=> 'fa-1x',
			'style_font'				=> 'sync-with-title',
			'image_size'				=> 'full',
			'title'						=> '1',
			'show_excerpt'				=> '1',
			'number_word'				=> '10',
			'readmore'					=> '1',
			'open_link_with'			=> 'modal',
			'readmore_text'				=> 'Read More',
			'is_slider'					=> '0',
			'show_nav'					=> '1',
			'auto_play'					=> '1',
			'style_class'				=> 'style-1',
			'class'						=> '',
		),$atts);
		$args_item 			= $atts;
		$args_item['type'] 	= 'multi';
		extract($atts);

		$args = array(
			'post_type'				=> 'wd_feature',
			'post_status'			=> 'publish',
			'posts_per_page' 		=> $number_feature,
			'order' 				=> $sort,
			'orderby'				=> $order_by,
		);

		if( $id != 0 && $id != '-1' ){
			$args['tax_query']= array(
		    	array(
			    	'taxonomy' 		=> 'wd_feature_categories',
					'terms' 		=> $id,
					'field' 		=> 'term_id',
					'operator' 		=> 'IN'
				)
   			);
		}
		$_feature 	= new WP_Query($args);

		if ($is_slider) {
			$wrap_class = '';
			$list_class	= 'wd-slider-wrap wd-slider-wrap--featured';
			$slider_options = json_encode(array(
				'slider_type' => 'owl',
				'column_desktop' => esc_attr($columns),
				'column_tablet' => esc_attr($columns_tablet),
				'column_mobile' => esc_attr($columns_mobile),
				'arrows' => $show_nav ? true : false,
				'autoplay' => $auto_play ? true : false,
			));
		}else{
			$wrap_class = ($is_slider == '0') ? 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile : '';
			$list_class	= 'wd-columns-list-item';
			$slider_options	= '';
		}

		ob_start();
		if ( $_feature->have_posts() ) { ?>
			<div class="wd-feature-category-wrapper <?php echo esc_attr( $wrap_class ); ?> <?php echo esc_attr($class); ?>">
				<ul class="wd-feature-content-list <?php echo esc_attr( $list_class ); ?>" 
					data-slider-options='<?php echo esc_attr( $slider_options ); ?>'>
					<?php 
					while( $_feature->have_posts() ) { $_feature->the_post();
						echo wd_get_future_content_item($args_item); 
					} ?> <!-- end while -->
				</ul>
			</div>
			<?php
		}
		$output = ob_get_clean();
		wp_reset_query();
		return $output;
	}
}
add_shortcode('wd_feature_category','wd_feature_category_function');
?>