<?php 
if( !function_exists('wd_portfolio_get_list_category') ){
	function wd_portfolio_get_list_category($list_cats = -1) { 
		$list_cats 	= ($list_cats != -1) ? explode(',' , $list_cats) : $list_cats; 
		$args 		= array(
			'taxonomy'     => 'wd-portfolio-category',
		);
		if ($list_cats != -1) {
			$args['include']  = $list_cats;
		}

		$list_cats_new 	= array();
		$categories 	= get_terms( $args );
		if (count($categories) > 0) {
			foreach ($categories as $cat) {
				$list_cats_new[$cat->slug] = $cat->name;
			}
		}
		return $list_cats_new;
	}
} 

if( !function_exists('wd_portfolio_class_slug_category') ){
	function wd_portfolio_class_slug_category() { 
		global $post;
		$list_cats_new 	= array();
		$categories		= get_the_terms( $post, 'wd-portfolio-category' );
		
		if (count($categories) > 0) {
			foreach ($categories as $cat) {
				$list_cats_new[] = $cat->slug;
			}
		}
		echo implode(' ', $list_cats_new);
	}
} 




if( !function_exists('wd_portfolio_filter_tools') ){
	function wd_portfolio_filter_tools($wrap_id, $list_cats = -1, $columns = 2) { 
		$list_cats =  wd_portfolio_get_list_category($list_cats); ?>
		<div class="wd-portfolio-category-filter-tool" data-wrap-id="<?php echo esc_attr($wrap_id); ?>">

			<div class="wd-portfolio-filter-by-cat">
				<p><?php esc_html_e( 'Sort Portfolio', 'wd_package' ) ?></p>
				<a class="wd-portfolio-filter-by-cat-item active" href="#all"><?php esc_html_e( 'ALL', 'wd_package' ) ?></a>
				<?php if (count($list_cats) > 0): ?>
					<?php foreach ($list_cats as $slug => $name): ?>
						<a class="wd-portfolio-filter-by-cat-item" href="#<?php echo $slug; ?>"><?php echo $name; ?></a>
					<?php endforeach ?>
				<?php endif ?>
			</div> 

			<div class="wd-portfolio-filter-sort-by hidden">
				<ul>
					<?php
					$list_sort_by = array(
						'name'	=> esc_html__( 'Name', 'wd_package' ),
						'date'	=> esc_html__( 'Date', 'wd_package' ),
					);  
					foreach ($list_sort_by as $sort_by => $title){ ?>
						<li data-option-value="<?php echo $sort_by; ?>" id="wd-columns-toggle-<?php echo $sort_by; ?>" class="goAction wd-tooltip wd-columns-toggle" data-toggle="tooltip" title="<?php printf(esc_html__( 'Sort by %s', 'wd_package' ), $title); ?>">
							<a href="#"><?php echo $title; ?></a>
						</li>
					<?php } ?>
				</ul>
			</div>
				
			<div class="wd-portfolio-filter-by-columns">
				<form action="#" method="get">
					<select class="wd-portfolio-columns-select" name="wd-portfolio-columns-select" data-column="<?php echo esc_attr( $columns ); ?>">
						<?php
						$list_columns = array(
							'1'	=> esc_html__( '1 Columns', 'wd_package' ),
							'2'	=> esc_html__( '2 Columns', 'wd_package' ),
							'3'	=> esc_html__( '3 Columns', 'wd_package' ),
							'4'	=> esc_html__( '4 Columns', 'wd_package' ),
							'5'	=> esc_html__( '5 Columns', 'wd_package' ),
							'6'	=> esc_html__( '6 Columns', 'wd_package' ),
							'8'	=> esc_html__( '8 Columns', 'wd_package' ),
							'12' => esc_html__( '12 Columns', 'wd_package' ),
						);  
						foreach ($list_columns as $column => $title){ 
							$selected = ($columns == $column) ? 'selected="selected"' : '';
							?>
							<option <?php echo $selected; ?> value="<?php echo $column; ?>"><?php echo $title; ?></option>
						<?php } ?>
					</select>
				</form>
			</div>

		</div>
		<?php
	}
} 
