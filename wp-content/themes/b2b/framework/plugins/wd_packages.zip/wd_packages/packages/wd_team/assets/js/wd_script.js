//****************************************************************//
/*							Main JS								  */
//****************************************************************//
jQuery(document).ready(function($) {
	"use strict";
	//Skill Bar
	wd_skill_bar();
});

//****************************************************************//
/*							FUNCTIONS							  */
//****************************************************************//
//Skill Bar
if (typeof wd_skill_bar != 'function') { 
	function wd_skill_bar(){
		if(jQuery('.wd-skillbar').length > 0 ){
			jQuery('.wd-skillbar').each(function(){
				jQuery(this).find('.wd-skillbar-bar').animate({
					width:jQuery(this).attr('data-percent')
				},6000);
			});
		}
	}
}