<?php
/**
 * Shortcode: wd_currency_switcher
 */

if (!function_exists('wd_currency_switcher_site')) {
	function wd_currency_switcher_site($atts) {
		extract(shortcode_atts(array(
			'style'			=> 'dropdown',
			'title'			=> 'symbol',
			'show_reset'	=> '0',
			'show_flag'		=> '0',
			'flag_position'	=> 'left',
			'class' 		=> ''
		), $atts));
		$current_name 		= !empty($_COOKIE['woocommerce_current_currency']) ? $_COOKIE['woocommerce_current_currency'] : get_option( 'woocommerce_currency' );
		$current_name 		= ($current_name) ? $current_name : 'USD';
		$current_symbol		= get_woocommerce_currency_symbol($current_name);
		$list_woo_currency 	= get_woocommerce_currencies();

		$current_flag  			= $show_flag ? '<div class="currency-flag currency-flag-'.strtolower($current_name).'"></div>' : '';
		$current_title_content 	= '';
		if ($title == 'name' ) {
			$current_title_content = $list_woo_currency[$current_name];
		}elseif ($title == 'symbol' ) {
			$current_title_content = $current_symbol;
		}elseif ($title == 'currency' ) {
			$current_title_content = $current_name;
		}elseif ($title == 'name-symbol' ) {
			$current_title_content = $list_woo_currency[$current_name] . ' (' .$current_symbol.')';
		}elseif ($title == 'name-currency' ) {
			$current_title_content = $list_woo_currency[$current_name] . ' | ' .$current_name;
		}elseif ($title == 'currency-symbol' ) {
			$current_title_content = $current_name . ' (' .$current_symbol.')';
		}
		if ($show_flag) {
			$current_title_content = ($flag_position == 'left') ? $current_flag.' '.$current_title_content : $current_title_content.' '.$current_flag;
		}

		$style_class 	= 'wd-currency-switcher-'.$style;
		$random_id 		= 'wd-currency-switcher-form-'.rand(0,1000).time();
		ob_start(); ?>
		<div class="wd-shortcode-currency-switcher <?php echo esc_attr($class) ?> <?php echo esc_attr($style_class) ?>">
			<?php if ($style == 'dropdown'): ?>
				<div class="wd-navUser-action-wrap wd-dropdown-wrap">
					<a href="javascript: void(0)" class="wd-navUser-action wd-navUser-action--currency">
						<?php echo $current_title_content; ?>
					</a>
					<div class="wd-dropdown-container wd-dropdown--currency">
			<?php endif ?>
						<form method="post" id="<?php echo esc_html($random_id); ?>" action="">
							<div>
								<?php
									$currencies 		= get_option( 'wc_currency_converter_set_currency' );
									if ( $currencies ) {
										echo '<ul class="currency_switcher">';
										foreach ( $currencies as $currency_name ) {
											$currency_symbol= get_woocommerce_currency_symbol($currency_name);
											$flag  			= $show_flag ? '<div class="currency-flag currency-flag-'.strtolower($currency_name).'"></div>' : '';
											$class 			= ( $currency_name == get_option( 'woocommerce_currency' ) ) ? 'wd-currency-opiton reset default' : 'wd-currency-opiton';
											$title_content  = '';
											if ($title == 'name' ) {
												$title_content = $list_woo_currency[$currency_name];
											}elseif ($title == 'symbol' ) {
												$title_content = $currency_symbol;
											}elseif ($title == 'currency' ) {
												$title_content = $currency_name;
											}elseif ($title == 'name-symbol' ) {
												$title_content = $list_woo_currency[$currency_name] . ' (' .$currency_symbol.')';
											}elseif ($title == 'name-currency' ) {
												$title_content = $list_woo_currency[$currency_name] . ' | ' .$currency_name;
											}elseif ($title == 'currency-symbol' ) {
												$title_content = $currency_name . ' (' .$currency_symbol.')';
											}
											if ($show_flag) {
												$title_content = ($flag_position == 'left') ? $flag.' '.$title_content : $title_content.' '.$flag;
											}

											echo '<li><a href="#" class="' . esc_attr( $class ) . '" data-currencycode="' . esc_attr( $currency_name ) . '">' . $title_content . '</a></li>';
										}

										if ( $show_reset )
											echo '<li><a href="#" class="reset">' . __('Reset', 'wd_package') . '</a></li>';

										echo '</ul>';
									}
								?>
							</div>
						</form>
			<?php if ($style == 'dropdown'): ?>
					</div>
				</div>
			<?php endif ?>	
		</div>
		<?php
		$content = ob_get_clean();
		return $content;
	}
}
add_shortcode('wd_currency_switcher', 'wd_currency_switcher_site');
?>