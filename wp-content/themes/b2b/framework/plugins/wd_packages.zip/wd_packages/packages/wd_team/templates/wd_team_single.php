<?php
/**
 * Shortcode: wd_team_member
 */

if (!function_exists('wd_team_member_single_function')) {
	function wd_team_member_single_function($atts) {
		extract(shortcode_atts(array(
			'id_team'				=> '',
			'image_size'			=> 'wd-team-member-image-size-1',
			'style'					=> 'style-1',
			'class'					=> '',
		), $atts));

		$args 	= array( 
			'post_type' 	=> 'team',
			'post_status' 	=> 'publish',
			'post__in' 		=> array($id_team),
		);
		$random_id 			= 'wd-shortcode-team-member-single-'.mt_rand();	
		$style_class 		= 'wd-team-member-'.$style;	
		wp_reset_postdata();
		$teammember 	= new WP_Query($args);
		ob_start();
		
		?>
		<div class="wd-shortcode-team-member-single <?php echo esc_attr($style_class) ?> <?php echo esc_attr($class) ?>" >
			<?php if($id_team == '' || $id_team == '-1'){ ?>
				<p><?php esc_html_e('Please select team','wd_package'); ?></p>
			<?php }else{ ?>
				<?php while ($teammember->have_posts()) : $teammember->the_post(); global $post; ?>
					<?php echo wd_team_member_get_single_template($style, $image_size); ?>
				<?php endwhile;// End While ?>
			<?php } // End if ?>
		</div>

		<?php
		$content = ob_get_clean();
		wp_reset_postdata();
		return $content;
	}
}
add_shortcode('wd_team_member_single', 'wd_team_member_single_function');
?>