<?php
# Visual Composer installed?
if ( function_exists( 'visual_composer' ) && ! function_exists( 'wd_vc_shortcodes_portfolio_grid' ) ) {
	/**
	 * Add theme's custom shortcodes to Visual Composer
	 */
	function wd_vc_shortcodes_portfolio_grid() {
		$categories  = wd_vc_get_list_category('wd-portfolio-category', false, 'sorted_list');
		vc_map( array(
			'name'        => __( 'WD - Portfolio Grid', 'wd_package' ),
			'base'        => 'wd_portfolio_gird',
			'description' => __( 'Special Grid portfolio', 'wd_package' ),
			'category'    =>esc_html__("WD - Content", 'wd_package'),
			'icon'        => 'vc_icon-vc-media-grid',
			'params'      => array(
				array(
					'type' 			=> 'sorted_list',
					'heading' 		=> __( 'Categories', 'wd_package' ),
					'param_name' 	=> 'id_category',
					'description' 	=> __( 'Select and sort portfolio categories. Leave blank if you want to display all portfolio category', 'wd_package' ),
					'value' 		=> '-1',
					'options' 		=> $categories,
					'dependency'  	=> array('element' => 'type', 'value'   => array( 'categories' )),
				),
				array(
					'type'        => 'textfield',
					'heading'     => __( 'Number Of Portfolio', 'wd_package' ),
					'param_name'  => 'number_portfolio',
					'admin_label' => true,
					'value'       => '12',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Style', 'wd_package' ),
					'param_name'  => 'style',
					'admin_label' => true,
					'value'       => array(
						__( 'Style 1', 'wd_package' ) => 'wd-portfolio-style-1',
						__( 'Style 2', 'wd_package' ) => 'wd-portfolio-style-2',
						__( 'Style 3', 'wd_package' ) => 'wd-portfolio-style-3',
					),
					'description' => '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Image Size', 'wd_package' ),
					'param_name' 	=> 'image_size',
					'admin_label' 	=> true,
					'value' 		=> wd_vc_get_list_image_size(),
					'std'			=> 'full',
					'description' 	=> '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Sort By', 'wd_package' ),
					'param_name' 	=> 'sort',
					'admin_label' 	=> true,
					'value' 		=> wd_vc_get_sort_by_values(),
					'std'			=> 'DESC',
					'description' 	=> '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Order By', 'wd_package' ),
					'param_name' 	=> 'order_by',
					'admin_label' 	=> true,
					'value' 		=> wd_vc_get_order_by_values(),
					'std'			=> 'date',
					'description' 	=> '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Columns', 'wd_package' ),
					'param_name' 	=> 'columns',
					'admin_label' 	=> true,
					'value' 		=> wd_vc_get_list_tvgiao_columns(),
					'std'			=> '1',
					'description' 	=> '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' 				=> 'dropdown',
					'heading' 			=> esc_html__( 'Columns On Tablet', 'wd_package' ),
					'param_name' 		=> 'columns_tablet',
					'admin_label' 		=> true,
					'value' 			=> wd_vc_get_list_columns_tablet(),
					'std'				=> 2,
					'description' 		=> esc_html__( '', 'wd_package' ),
					"group"				=> esc_html__('Responsive', 'wd_package'),
				),
				array(
					'type' 				=> 'dropdown',
					'heading' 			=> esc_html__( 'Columns On Mobile', 'wd_package' ),
					'param_name' 		=> 'columns_mobile',
					'admin_label' 		=> true,
					'value' 			=> wd_vc_get_list_columns_mobile(),
					'std'				=> 1,
					'description' 		=> esc_html__( '', 'wd_package' ),
					"group"				=> esc_html__('Responsive', 'wd_package'),
				),
				array(
					"type" 			=> "textfield",
					"class" 		=> "",
					"heading" 		=> esc_html__("Padding", 'wd_package'),
					"param_name" 	=> "padding",
					"value"			=> 0,
					"description" 	=> esc_html__('Padding between images. Only fill in whole numbers or real numbers. Example: 2.5 (Unit: pixels)', 'wd_package'),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type'        => 'textfield',
					'heading'     => __( 'Number of excerpt words', 'wd_package' ),
					'param_name'  => 'excerpt_words',
					'admin_label' => true,
					'value'       => '20',
					'description' => '',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Show Pagination Or Load More', 'wd_package' ),
					'param_name'  => 'pagination_loadmore',
					'admin_label' => true,
					'value'       => array(
						__( 'Load More', 'wd_package' )  => 'loadmore',
						__( 'Pagination', 'wd_package' ) => 'pagination',
						__( 'Filter', 'wd_package' ) 	 => 'filter',
						__( 'No Show', 'wd_package' )    => '0',
					),
					'description' => '',
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Number Item Load More', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'number_loadmore',
					'value'       => '8',
					'description' => '',
					'dependency'  => Array( 'element' => 'pagination_loadmore', 'value' => array( '0' ) ),
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Extra class name', 'wd_package' ),
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'class',
					'value'       => '',
				),
			),
		) );
	}
}

# add theme's custom shortcodes to Visual Composer
add_action( 'vc_before_init', 'wd_vc_shortcodes_portfolio_grid' );
