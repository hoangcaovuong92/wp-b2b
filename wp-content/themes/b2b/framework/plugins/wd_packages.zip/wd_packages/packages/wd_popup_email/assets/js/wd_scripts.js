//****************************************************************//
/*							Main JS								  */
//****************************************************************//
jQuery(document).ready(function($) {
	"use strict";
	//wd_email_popup_scripts()
});

//****************************************************************//
/*							FUNCTIONS							  */
//****************************************************************//
//Thickbox responsive
if (typeof wd_thickbox_responsive != 'function') { 
	function wd_thickbox_responsive(TB_WIDTH, TB_HEIGHT) {
		jQuery('.tb-close-icon').click(function() {
	        tb_remove();
	    });
	    
		var window_width 	= jQuery(window).width();
		var window_height 	= jQuery(window).height();

		if(TB_WIDTH > window_width || TB_HEIGHT > window_height){
			jQuery("#TB_window").css({margin: '2%'});
			jQuery("#TB_ajaxContent, #TB_iframeContent").css({width: '100%', height:'100%'});
			jQuery("#TB_closeWindowButton").css({fontSize: '24px', marginRight: '5px'});
		}
		if(TB_WIDTH > window_width){
			jQuery("#TB_window").css({width: '96%', left: 0});
			if(TB_HEIGHT > window_height){
				jQuery("#TB_window").css({height:'94%', top:0});
			}
		}else{
		    jQuery("#TB_window").css({marginLeft: '-' + parseInt((TB_WIDTH / 2),10) + 'px', width: TB_WIDTH + 'px'});
		}

		if(TB_HEIGHT > window_height || window_width < 768){
			jQuery("#TB_window").css({height:'94%', top:0});
			if(TB_WIDTH > window_width){
				jQuery("#TB_window").css({width: '96%', left: 0});
			}
		}else{
		    jQuery("#TB_window").css({marginTop: '-' + parseInt((TB_HEIGHT / 2),10) + 'px', height: TB_HEIGHT + 'px'});
		    jQuery("#TB_ajaxContent, #TB_iframeContent").css({height:TB_HEIGHT});
		}
	}
}

//Email subscribe popup script
if (typeof wd_accessibility_email_subscribe_popup != 'function') { 
	function wd_accessibility_email_subscribe_popup(TB_WIDTH, TB_HEIGHT, delay_time) {
        setTimeout(function(){ 
            tb_remove();
            tb_show('', '#TB_inline?width='+TB_WIDTH+'&height='+TB_HEIGHT+'&inlineId=wd-email-subscribe-popup&modal=true');

            jQuery('#wd-email-subscribe-content').parents('#TB_ajaxContent').css('overflow', 'hidden');
            jQuery('.tb-close-icon').click(function() {
                tb_remove();
                var value = jQuery('.wd-email-subscribe-popup-disabled').is(':checked') ? true : false;
                if (value) {
                    var expire   = jQuery('.wd-email-subscribe-popup-disabled').data('expire');
                    jQuery.ajax({
                        type: 'POST',
                        url: ajax_object.ajax_url,
                        data: { 
                            action: 'wd_ajax_disabled_email_popup',
                            expire: expire,
                        },
                        success: function(data) {
                        }
                    });
                }
            });
            wd_thickbox_responsive(TB_WIDTH, TB_HEIGHT);
        }, 3000);
	}
}