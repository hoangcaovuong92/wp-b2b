<?php
if( !class_exists( 'wd_widget_feature' ) ) {
	class wd_widget_feature extends WD_Widgets_Fields {
		public function __construct() {
			$this->widget_init();
		}
		
		public function init_settings(){
			$this->list_widget_field_default = array(
				'id'						=> 0,
				'show_icon_font_thumbnail'	=> 'show-image',
				'feature_icon_or_custom_icon' => 'feature-icon',
				'icon_fontawesome' 			=> 'fa fa-heartbeat',
				'icon_size'					=> 'fa-1x',
				'style_font'				=> 'sync-with-title',
				'image_or_thumbnail'		=> 'custom-image',
				'custom_image'				=> '',
				'image_size'				=> 'full',
				'text_align'				=> 'text-left',
				'title'						=> '1',
				'show_excerpt'				=> '1',
				'number_word'				=> '10',
				'readmore'					=> '0',
				'open_link_with'			=> 'modal',
				'readmore_text'				=> 'Read More',
				'style_class'				=> 'style-1',
				'class'						=> '',
			);
			$this->widget_name = esc_html__('WD - Feature Single','wd_package');
			$this->widget_desc = esc_html__('Display detail of single feature...','wd_package');
			$this->widget_slug = 'widget_feature';
			$this->callback = 'wd_features_function';
		}

		public function form( $instance ) {
	       	foreach ($this->list_widget_field_default as $key => $value) {
	    		${$key}   	= isset( $instance[$key] ) ? esc_attr( $instance[$key] ) : $value;
	    	}

	    	$id_arr              = wd_get_data_by_post_type('wd_feature');
	    	$show_icon_font_thumbnail_arr = array(
	    		'show-icon' 	=> 'Show Icon Font',
				'show-image' 	=> 'Show Image/Thumbnail',
				'hide' 			=> 'Hide Icon & Thumbnail',
	    	);
            $icon_size_arr      = wd_get_list_awesome_font_size();
            $style_font_arr     = array(
                    'sync-with-title'       => 'Sync with title',
                    'separate-from-title'   => 'Separate from title'
                );

	    	$image_or_thumbnail_arr = array(
	    		'feature-thumbnail' => 'Show Thumbnail',
				'custom-image' 		=> 'Show Custom Image',
	    	);
	    	$image_size_arr 	= wd_get_list_image_size();
	    	$text_align_arr 	= wd_get_list_text_align_bootstrap();
	    	$title_arr 			= wd_get_list_tvgiao_boolean();
	    	$show_excerpt_arr 	= wd_get_list_tvgiao_boolean();
	    	$readmore_arr 		= wd_get_list_tvgiao_boolean();
	    	$open_link_with_arr = array(
				'modal' => 'Modal Popup',
				'link' 	=> 'Feature Link',
			);
			$style_class_arr 	= wd_get_list_style_class(2);
			
            $this->select_field(
                esc_html__( 'Feature ID:', 'wd_package' ), 
                $this->get_field_name( 'id' ), 
                $this->get_field_id( 'id' ), 
                $id_arr, 
                $id
            );

            $this->select_field(
                esc_html__( 'Show Thumbnail Or Icon Font:', 'wd_package' ), 
                $this->get_field_name( 'show_icon_font_thumbnail' ), 
                $this->get_field_id( 'show_icon_font_thumbnail' ), 
                $show_icon_font_thumbnail_arr, 
                $show_icon_font_thumbnail
            );

            $this->hidden_field(
                $this->get_field_name( 'feature_icon_or_custom_icon' ), 
                $this->get_field_id( 'feature_icon_or_custom_icon' ), 
                $feature_icon_or_custom_icon
            );

            $this->select_field(
                esc_html__( 'Icon Size (Icon Setting):', 'wd_package' ), 
                $this->get_field_name( 'icon_size' ), 
                $this->get_field_id( 'icon_size' ), 
                $icon_size_arr, 
                $icon_size
            );

            $this->select_field(
                esc_html__( 'Style Font Icon (Icon Setting):', 'wd_package' ), 
                $this->get_field_name( 'style_font' ), 
                $this->get_field_id( 'style_font' ), 
                $style_font_arr, 
                $style_font
            );

            $this->select_field(
                esc_html__( 'Image Or Thumbnail (Image Setting):', 'wd_package' ), 
                $this->get_field_name( 'image_or_thumbnail' ), 
                $this->get_field_id( 'image_or_thumbnail' ), 
                $image_or_thumbnail_arr, 
                $image_or_thumbnail
            );

            $this->image_field(	
        		esc_html__( 'Custom Image (Image Setting):', 'wd_package' ), 
        		$this->get_field_name( 'custom_image' ), 
        		$this->get_field_id( 'custom_image' ), 
        		$custom_image, 
        		'', 
        		esc_html__("", 'wd_package')
        	);

        	$this->select_field(
                esc_html__( 'Thumbnail Size (Image Setting):', 'wd_package' ), 
                $this->get_field_name( 'image_size' ), 
                $this->get_field_id( 'image_size' ), 
                $image_size_arr, 
                $image_size
            );

            $this->select_field(
                esc_html__( 'Text Align:', 'wd_package' ), 
                $this->get_field_name( 'text_align' ), 
                $this->get_field_id( 'text_align' ), 
                $text_align_arr, 
                $text_align
            );

            $this->select_field(
                esc_html__( 'Show feature title:', 'wd_package' ), 
                $this->get_field_name( 'title' ), 
                $this->get_field_id( 'title' ), 
                $title_arr, 
                $title
            );

            $this->select_field(
                esc_html__( 'Show excerpt:', 'wd_package' ), 
                $this->get_field_name( 'show_excerpt' ), 
                $this->get_field_id( 'show_excerpt' ), 
                $show_excerpt_arr, 
                $show_excerpt
            );

            $this->text_field(
    			esc_html__( 'Number Word Excerpt:', 'wd_package' ), 
    			$this->get_field_name( 'number_word' ),
    			$this->get_field_id( 'number_word' ),
    			$number_word, 
    			esc_html__("Set -1 to show full excerpt", 'wd_package')
    		);

    		$this->select_field(
                esc_html__( 'Show Readmore:', 'wd_package' ), 
                $this->get_field_name( 'readmore' ), 
                $this->get_field_id( 'readmore' ), 
                $readmore_arr, 
                $readmore
            );

            $this->select_field(
                esc_html__( 'Open Link With (Readmore Setting):', 'wd_package' ), 
                $this->get_field_name( 'open_link_with' ), 
                $this->get_field_id( 'open_link_with' ), 
                $open_link_with_arr, 
                $open_link_with
            );

    		$this->text_field(
    			esc_html__( 'Readmore Text (Readmore Setting):', 'wd_package' ), 
    			$this->get_field_name( 'readmore_text' ),
    			$this->get_field_id( 'readmore_text' ),
    			$readmore_text, 
    			esc_html__("Leave blank if you want to use single feature read more text setting.", 'wd_package')
    		);

    		$this->select_field(
                esc_html__( 'Style:', 'wd_package' ), 
                $this->get_field_name( 'style_class' ), 
                $this->get_field_id( 'style_class' ), 
                $style_class_arr, 
                $style_class
            );
           
    		$this->text_field(
    			esc_html__( 'Extra class name:', 'wd_package' ), 
    			$this->get_field_name( 'class' ),
    			$this->get_field_id( 'class' ),
    			$class, 
    			esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package')
    		);
	    }
	}
	function wp_widget_register_widget_feature() {
		register_widget( 'wd_widget_feature' );
	}
	add_action( 'widgets_init', 'wp_widget_register_widget_feature' );
}