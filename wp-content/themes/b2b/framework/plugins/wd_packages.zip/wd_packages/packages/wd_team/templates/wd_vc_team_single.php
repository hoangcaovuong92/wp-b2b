<?php
# Visual Composer installed?
if (function_exists('visual_composer')) {
	/****************************************************************************/
	/*							Team Member 									*/
	/****************************************************************************/
	$team_member_array 	= wd_vc_get_data_by_post_type('team');
	$team_category 		= wd_vc_get_list_category('team_categories');

	# Add shortcode Site Header
	vc_map(array(
		'name' 				=> esc_html__("WD - Team Memmber (Single)", 'wd_package'),
		'base' 				=> 'wd_team_member_single',
		'description' 		=> esc_html__("Display info a team member...", 'wd_package'),
		'category' 			=> esc_html__("WD - Content", 'wd_package'),
		'icon'        		=> 'icon-wpb-ninjaforms',
		'params' => array(
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__('Select Team', 'wd_package' ),
				'param_name' 		=> 'id_team',
				'admin_label' 		=> true,
				'value' 			=> $team_member_array,
				'description' 		=> '',
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Thumbnail Size', 'wd_package' ),
				'param_name' 	=> 'image_size',
				'admin_label' 	=> true,
				'value' 		=> wd_vc_get_list_image_size(),
				'description' 	=> '',
				'std'			=> 'wd-team-member-image-size-1',
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' 				=> 'dropdown',
				'heading' 			=> esc_html__( 'Style', 'wd_package' ),
				'param_name' 		=> 'style',
				'admin_label' 		=> true,
				'value' 			=> wd_vc_get_list_style_class(3),
				'description' 		=> '',
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wd_package'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
}

?>