<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Wordpress
 */

get_header();
global $post;
/**
 * package: single_team_member
 * var: layout_style 		
 * var: display_project 	
 * var: background 	
 */

$single_team_member_package = get_option('wd-theme-options-packages', array());
if (!count($single_team_member_package) || !is_array($single_team_member_package)) return;
extract($single_team_member_package['single_team_member']); 

//Count Post view
do_action('wd_set_post_views');
$background_url 	= wd_team_member_get_part_banner_image_url();
$background_url 	= $background_url == '' ? $background['url'] : $background_url;
$background_style 	= $background_url != '' ? 'style="background: url('.$background_url.');"' : '';

$class 				= 'wd-single-team-member-'.$layout_style;
?>
<div id="wd-main-content-wrap" class="wd-main-content-wrap"> 
	<?php if ($layout_style == 'style-1'): ?>
		<section class="wd-single-team-member-about container-fluid <?php echo esc_attr( $class ); ?>" <?php echo $background_style; ?>>
			<div class="container">
				<?php echo wd_team_member_get_part_thumbnail('wd-team-member-image-size-1'); ?>
				<?php echo wd_team_member_get_part_about(array('short_about' => '1')); ?>
				<?php echo wd_team_member_get_part_count_view(); ?>
				<div class="wd-single-team-member-about-detail">
					<a class="wd-button-click-to-slidedown"><?php esc_html_e( 'Click to About Me', 'wd_package' ) ?></a>
				</div>
			</div>
		</section>
		<div class="container">
			<div class="row">
				<div class="wd-single-team-member-wrap <?php echo esc_attr( $class ); ?>">
					<section class="wd-single-team-member-detail wd-content-click-to-slidedown">
						<div class="wd-single-team-member-detail-col-50">
							<div class="wd-team-member-about">
								<span><?php esc_html_e( 'ABOUT', 'wd_package' ) ?></span>
								<?php echo wd_team_member_get_part_about(array('website' => '0', 'social' => '0')); ?>
								<?php echo wd_team_member_get_part_description(); ?>
							</div>

							<div class="wd-team-member-skill">
								<span><?php esc_html_e( 'SKILL', 'wd_package' ) ?></span>
								<?php echo wd_team_member_get_part_skill( array('style' => 'list')); ?>
							</div>
						</div>
						<div class="wd-single-team-member-detail-col-50">
							<div class="wd-team-member-job">
								<span><?php esc_html_e( 'WORK EXPERIENCE', 'wd_package' ) ?></span>
								<?php echo wd_team_member_get_part_job(); ?>
							</div>
							<div class="wd-team-member-web-references">
								<span><?php esc_html_e( 'WEB REFERENCES', 'wd_package' ) ?></span>
							<?php echo wd_team_member_get_part_website(); ?>
							</div>
							<div class="wd-team-member-social">
								<span><?php esc_html_e( 'ON THE WEB', 'wd_package' ) ?></span>
								<?php echo wd_team_member_get_part_social(); ?>
							</div>
						</div>
					</section>
					
					<section class="wd-single-team-member-project">
						<div class="wd-single-team-member-project-title">
							<h3><?php esc_html_e( 'Projects', 'wd_package' ) ?></h3>
						</div>
						<?php echo wd_team_member_get_part_project(); ?>
					</section>
				</div>
			</div><!-- .row -->
		</div><!-- .container -->
	<?php elseif ($layout_style == 'style-2'): ?>
		<div class="container">
			<div class="row">
				<div class="wd-single-team-member-wrap <?php echo esc_attr( $class ); ?>">
					
					<section class="wd-single-team-member-about">
						<div class="container">
							<?php echo wd_team_member_get_part_thumbnail('wd-team-member-image-size-1'); ?>
							<div class="wd-single-team-member-detail">
								<?php echo wd_team_member_get_part_about(array('short_about' => '1')); ?>

								<?php 
								$content_tab 	= array();
								$content_tab[]	= array(
											'title' 	=> esc_html__( 'About Me', 'wd_package' ),
											'content' 	=> wd_team_member_get_part_about().wd_team_member_get_part_description().wd_team_member_get_part_count_view(),
										);
								$content_tab[]	= array(
											'title' 	=> esc_html__( 'Work Experience', 'wd_package' ),
											'content' 	=> wd_team_member_get_part_job(),
										);
								$content_tab[]	= array(
											'title' 	=> esc_html__( 'Skill', 'wd_package' ),
											'content' 	=> wd_team_member_get_part_skill(),
										);
								echo wd_tab_bootstrap($content_tab); ?>
							</div>
						</div>
					</section>

					<section class="wd-single-team-member-project">
						<div class="wd-single-team-member-project-title">
							<h3><?php esc_html_e( 'Projects', 'wd_package' ) ?></h3>
						</div>
						<?php echo wd_team_member_get_part_project(); ?>
					</section>
					
				</div>
			</div><!-- .row -->
		</div><!-- .container -->
	<?php elseif ($layout_style == 'style-3'): ?>
		<section class="wd-single-team-member-about container-fluid <?php echo esc_attr( $class ); ?>" <?php echo $background_style; ?>>
			<div class="container">
				<?php echo wd_team_member_get_part_thumbnail('wd-team-member-image-size-1'); ?>
				<?php echo wd_team_member_get_part_about(array('short_about' => '1')); ?>
			</div>
		</section>
		<section class="wd-single-team-member-detail container-fluid <?php echo esc_attr( $class ); ?>">
			<div class="container">
				<?php echo wd_team_member_get_part_count_view(); ?>
				<div class="wd-single-team-member-project-title">
					<h3><?php esc_html_e( 'Projects', 'wd_package' ) ?></h3>
					<div class="wd-single-team-member-about-detail">
						<a class="wd-button-click-to-slidedown"><?php esc_html_e( 'About Me', 'wd_package' ) ?></a>
					</div>
				</div>
				<div class="wd-single-team-member-detail wd-content-click-to-slidedown">
					<div class="wd-single-team-member-detail-col-50">
						<div class="wd-team-member-about">
							<span><?php esc_html_e( 'ABOUT', 'wd_package' ) ?></span>
							<?php echo wd_team_member_get_part_about(array('website' => '0', 'social' => '0')); ?>
							<?php echo wd_team_member_get_part_description(); ?>
						</div>

						<div class="wd-team-member-skill">
							<span><?php esc_html_e( 'SKILL', 'wd_package' ) ?></span>
							<?php echo wd_team_member_get_part_skill( array('style' => 'list')); ?>
						</div>
					</div>
					<div class="wd-single-team-member-detail-col-50">
						<div class="wd-team-member-job">
							<span><?php esc_html_e( 'WORK EXPERIENCE', 'wd_package' ) ?></span>
							<?php echo wd_team_member_get_part_job(); ?>
						</div>
						<div class="wd-team-member-web-references">
							<span><?php esc_html_e( 'WEB REFERENCES', 'wd_package' ) ?></span>
						<?php echo wd_team_member_get_part_website(); ?>
						</div>
						<div class="wd-team-member-social">
							<span><?php esc_html_e( 'ON THE WEB', 'wd_package' ) ?></span>
							<?php echo wd_team_member_get_part_social(); ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<div class="container">
			<div class="row">
				<div class="wd-single-team-member-wrap <?php echo esc_attr( $class ); ?>">
					<section class="wd-single-team-member-project">
						<?php echo wd_team_member_get_part_project(); ?>
					</section>
				</div>
			</div><!-- .row -->
		</div><!-- .container -->
	<?php endif ?>
</div><!-- #main-content -->
<?php get_footer(); ?>