<?php
if (!class_exists('WD_Team')) {
	class WD_Team {
		/**
		 * Refers to a single instance of this class.
		 */
		private static $instance = null;

		public static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		protected $post_type 	= 'team';
		protected $taxonomy 	= 'team_categories';
		protected $arrShortcodes = array('team_single', 'team_category');

		public function __construct(){
			$this->constant();
			
			/****************************/
			// Register Team post type
			add_action('init', array($this, 'register_post_type'));
			
			if($this->checkPluginVC()){
				add_action('vc_before_init', array( $this, 'register_taxonomy' ) );
			}else{
				add_action('init', array( $this, 'register_taxonomy' ) );
			}

			add_filter('attribute_escape', array($this,'rename_second_menu_name') , 10, 2);
			add_theme_support('post-thumbnails', array($this->post_type) );

			//Change Placeholder Title Post
			add_filter( 'enter_title_here', array($this, 'change_title_text' ));
			
			add_action('admin_enqueue_scripts',array($this,'init_admin_script'));
			
			add_action('add_meta_boxes', array( $this,'create_metabox' ) );	
			add_action('pre_post_update', array($this,'metabox_save_data') , 10, 2);
			add_action('template_redirect', array($this,'template_redirect') );

			add_filter( 'single_template', array( $this, 'single_team_template' ) );
			add_filter( 'archive_template', array( $this, 'archive_team_template' ) );

			$this->init_handle();

			require_once( WDT_BASE . '/wd_functions.php' ); 
			
			//Visual Composer
			$this->initShortcodes();
			if($this->checkPluginVC()){
				if ( ! defined( 'ABSPATH' ) ) { exit; }
				add_action("vc_after_init",array($this,'initVisualComposer'));
			}
		}
		
		protected function constant(){
			define('WDT_BASE'		,   plugin_dir_path( __FILE__ ));
			define('WDT_BASE_URI'	,   plugins_url( '', __FILE__ ));
			define('WDT_JS'			, 	WDT_BASE_URI . '/assets/js'		);
			define('WDT_CSS'		, 	WDT_BASE_URI . '/assets/css'		);
			define('WDT_ADMIN_JS'	, 	WDT_BASE_URI . '/admin/js'		);
			define('WDT_ADMIN_CSS'	, 	WDT_BASE_URI . '/admin/css'		);
			define('WDT_IMAGE'		, 	WDT_BASE_URI . '/images'	);
			define('WDT_TEMPLATE' 	, 	WDT_BASE . '/templates'	);
			define('WDT_INCLUDES'	, 	WDT_BASE . '/includes'	);
		}

		/******************************** TEAM POST TYPE ***********************************/
		public function register_post_type(){
			if (!post_type_exists($this->post_type)) {
				register_post_type($this->post_type, array(
					'exclude_from_search' 	=> true,
					'labels' 				=> array(
		                'name' 				=> _x('WD Team', 'post type general name','wd_package'),
		                'singular_name' 	=> _x('WD Team', 'post type singular name','wd_package'),
		                'add_new' 			=> _x('Add Member', 'Team','wd_package'),
		                'add_new_item' 			=> sprintf( __( 'Add New %s', 'wd_package' ), __( 'Member', 'wd_package' ) ),
						'edit_item' 			=> sprintf( __( 'Edit %s', 'wd_package' ), __( 'Member', 'wd_package' ) ),
						'new_item' 				=> sprintf( __( 'New %s', 'wd_package' ), __( 'Member', 'wd_package' ) ),
						'all_items' 			=> sprintf( __( 'All %s', 'wd_package' ), __( 'Members', 'wd_package' ) ),
						'view_item' 			=> sprintf( __( 'View %s', 'wd_package' ), __( 'Member', 'wd_package' ) ),
						'search_items' 			=> sprintf( __( 'Search %a', 'wd_package' ), __( 'Members', 'wd_package' ) ),
						'not_found' 			=>  sprintf( __( 'No %s Found', 'wd_package' ), __( 'Members', 'wd_package' ) ),
						'not_found_in_trash' 	=> sprintf( __( 'No %s Found In Trash', 'wd_package' ), __( 'Features', 'wd_package' ) ),
		                'parent_item_colon' => '',
		                'menu_name' 		=> __('WD Team Member','wd_package'),
					),
					'singular_label' 		=> __('WD Team','wd_package'),
					'taxonomies' 			=> array($this->taxonomy),
					'public' 				=> true,
					'has_archive' 			=> false,
					'supports' 			 	=>  array('title','editor','thumbnail'),
					'has_archive' 			=> false,
					'rewrite' 				=>  array('slug'  =>  $this->post_type, 'with_front' =>  true),
					'show_in_nav_menus' 	=> false,
					'menu_icon'				=> 'dashicons-groups',
					'menu_position'			=> 58,
				));	
			}
		}

		public function register_taxonomy(){
			register_taxonomy( $this->taxonomy, $this->post_type, array(
				'hierarchical'     		=> true,
				'labels'            	=> array(
					'name' 				=> esc_html__('Categories Team', 'wd_package'),
					'singular_name' 	=> esc_html__('Category Team', 'wd_package'),
	            	'new_item'          => esc_html__('Add New', 'wd_package' ),
	            	'edit_item'         => esc_html__('Edit Post', 'wd_package' ),
	            	'view_item'   		=> esc_html__('View Post', 'wd_package' ),
	            	'add_new_item'      => esc_html__('Add New Category Team', 'wd_package' ),
	            	'menu_name'         => esc_html__( 'Categories Team' , 'wd_package' ),
				),
				'show_ui'           	=> true,
				'show_admin_column' 	=> true,
				'query_var'         	=> true,
				'rewrite'           	=> array( 'slug' => $this->taxonomy ),				
				'public'				=> true,
			));	
		}

		/******************************** Team POST TYPE INIT START ***********************************/
		public function single_team_template( $single ) {
			global $post;
			if ( $post->post_type == $this->post_type && file_exists( WDT_BASE . '/single-team.php' ) ) {
				return WDT_BASE . '/single-team.php';
			}

			return $single;
		}

		public function archive_team_template( $archive ) {
			global $post;
			if ($post) {
				if ( $post->post_type == $this->post_type && file_exists( WDT_BASE . '/archive-team.php' ) ) {
					return WDT_BASE . '/archive-team.php';
				}
			}
			return $archive;
		}

		public function metabox_save_data($post_id) {

			if ( ! isset( $_POST['wd_team_box_nonce'] ) )
				return $post_id;
			// verify this came from the our screen and with proper authorization,
			// because save_post can be triggered at other times
			if (!wp_verify_nonce($_POST['wd_team_box_nonce'],'wd_team_box'))
				return $post->ID;
			if (!current_user_can('edit_post', $post->ID))
				return $post->ID;

			$data = array();
			if (isset($_POST['wd_team_about'])) {
				$data['wd_team_about'] = $_POST['wd_team_about'];
			}
			if (isset($_POST['wd_team_web_referemces'])) {
				$data['wd_team_web_referemces'] = $_POST['wd_team_web_referemces'];
			}
			if (isset($_POST['wd_team_social'])) {
				$data['wd_team_social'] = $_POST['wd_team_social'];
			}
			if (isset($_POST['wd_team_role'])) {
				$meta_key 				= 'wd_team_role';
				$list_meta_name 		= array('role', 'company_name', 'company_url');
				$data['wd_team_role'] 	= $this->process_meta_data_repeatable_field_after_save($meta_key, $list_meta_name);
			}
			if (isset($_POST['wd_team_work_experiences'])) {
				$meta_key 				= 'wd_team_work_experiences';
				$list_meta_name 		= array('date_start', 'date_end', 'company_name', 'company_url', 'position');
				$data['wd_team_work_experiences'] = $this->process_meta_data_repeatable_field_after_save($meta_key, $list_meta_name);
			}
			if (isset($_POST['wd_team_skill'])) {
				$meta_key 				= 'wd_team_skill';
				$list_meta_name 		= array('name', 'level');
				$data['wd_team_skill'] 	= $this->process_meta_data_repeatable_field_after_save($meta_key, $list_meta_name);;
			}
			if (isset($_POST['wd_team_project'])) {
				$data['wd_team_project'] = $_POST['wd_team_project'];
			}
			update_post_meta($post_id,'wd_team_meta_data', serialize($data));
			
		}

		public function process_meta_data_repeatable_field_after_save($meta_key, $list_meta_name){
			$data 	= array();
			if (isset($_POST[$meta_key])) {
				foreach ($list_meta_name as $name) {
					if (count($_POST[$meta_key][$name]) > 0) {
						foreach ($_POST[$meta_key][$name] as $key => $value) {
							$data[$key][$name] = $value;
						}
					}
				}
				//Remove last item (repeatable field)
				unset($data[count($data)-1]);
			}
			return $data;
		}

		public function get_meta_data_default($field = ''){
			$default = array(
				'wd_team_about' 	=> array(
					'address'			=> '',
					'city'				=> '',
					'email'				=> '',
					'skype'				=> '',
					'phone'				=> '',
				),
				'wd_team_web_referemces'	=> array(
					'web_name'					=> '',
					'website'					=> '#',
				),
				'wd_team_social'	=> array(
					'facebook_link'		=> '#',
					'facebook_icon'		=> 'fa fa-facebook',
					'instagram_link'	=> '#',
					'instagram_icon'	=> 'fa fa-instagram',
					'twitter_link'		=> '#',
					'twitter_icon'		=> 'fa fa-twitter',
					'vimeo_link'		=> '#',
					'vimeo_icon'		=> 'fa fa-vimeo',
					'rss_link'			=> '#',
					'rss_icon'			=> 'fa fa-rss',
					'google_link'		=> '#',
					'google_icon'		=> 'fa fa-google-plus',
					'linkedin_link'		=> '#',
					'linkedin_icon'		=> 'fa fa-linkedin',
				),
				'wd_team_role'	=> array(
					array(
						'role'				=> '',
						'company_name'		=> '',
						'company_url'		=> '#',
					),
				),
				'wd_team_work_experiences'	=> array(
					array(
						'date_start'		=> date("d/m/Y"),
						'date_end'			=> date('d/m/Y', strtotime(' +1 day')),
						'company_name'		=> '',
						'company_url'		=> '#',
						'position'			=> '',
					),
				),
				'wd_team_skill'	=> array(
					array(
						'name'			=> '',
						'level'			=> '50',
					),
				),
				'wd_team_project'		=> array(),
			);
			return ($field && isset($default[$field])) ? $default[$field] : $default;
		}

		public function get_meta_data($field = ''){
			$default = $this->get_meta_data_default();
			$meta_data = get_post_meta( get_the_ID(), 'wd_team_meta_data', true );
			$meta_data = ($meta_data) ? wp_parse_args( unserialize($meta_data), $default ) : array();
			return ($field && isset($meta_data[$field])) ? $meta_data[$field] : $meta_data;
		}	
		
		public function template_redirect(){
			global $wp_query,$post,$page_datas,$data;
			if( $wp_query->is_page() || $wp_query->is_single() ){
				//if ( has_shortcode( $post->post_content, 'wd_team_member' ) ) { 
					add_action('wp_enqueue_scripts',array($this,'init_script'));
				//}
			}
		}
		
		public function create_metabox() {
			if(post_type_exists($this->post_type)) {
				add_meta_box("wp_cp_team_member_info", "ABOUT", array($this,"metabox_form_about"), "team", "normal", "high");
				add_meta_box("wp_cp_team_member_web_references", "WEB REFERENCES", array($this,"metabox_form_web_references"), "team", "normal", "high");
				add_meta_box("wp_cp_team_member_social", "SOCIALS", array($this,"metabox_form_social"), "team", "normal", "high");
				add_meta_box("wp_cp_team_member_role", "CURRENT JOB (ROLES)", array($this,"metabox_form_role"), "team", "normal", "high");
				add_meta_box("wp_cp_team_member_work_experience", "WORK EXPERIENCE", array($this,"metabox_form_work_experience"), "team", "normal", "high");
				add_meta_box("wp_cp_team_member_work_skill", "WORK SKILL", array($this,"metabox_form_work_skill"), "team", "normal", "high");
				if(post_type_exists('portfolio')) {
					add_meta_box("wp_cp_team_member_project", "PROJECT", array($this,"metabox_form_project"), "team", "normal", "high");
				}
			}
		}

		public function metabox_form_about(){
			wp_nonce_field( 'wd_team_box', 'wd_team_box_nonce' );
			$random_id 	= 'wd-team-member-metabox-'.mt_rand();
			$meta_key 	= 'wd_team_about';
			$meta_data 	= $this->get_meta_data($meta_key);
			$meta_data 	= empty($meta_data) ? $this->get_meta_data_default($meta_key) : $meta_data;
			?>
			<table id="<?php echo esc_attr( $random_id ); ?>" class="form-table wd-team-custom-meta-box wd-custom-meta-box-width">
				<tbody>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Address', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_about[address]" value="<?php echo esc_attr($meta_data['address']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'City & Country', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_about[city]" value="<?php echo esc_attr($meta_data['city']);?>"/></td>
					</tr>
			
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Email', 'wd_package' ); ?>:</label></th>
						<td><input type="email" class="wd-full-width" name="wd_team_about[email]" value="<?php echo esc_attr($meta_data['email']);?>"/></td> 
						<th scope="row"><label><?php esc_html_e( 'Skype', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_about[skype]" value="<?php echo esc_attr($meta_data['skype']);?>"/></td> 
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Phone', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_about[phone]" value="<?php echo esc_attr($meta_data['phone']);?>"/></td>
					</tr>
				</tbody>
			</table>
		<?php
		}

		public function metabox_form_web_references(){
			$random_id 	= 'wd-team-member-metabox-'.mt_rand();
			$meta_key 	= 'wd_team_web_referemces';
			$meta_data 	= $this->get_meta_data($meta_key);
			$meta_data 	= empty($meta_data) ? $this->get_meta_data_default($meta_key) : $meta_data;
			?>
			<table id="<?php echo esc_attr( $random_id ); ?>" class="form-table wd-team-custom-meta-box wd-custom-meta-box-width">
				<tbody>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Display Name', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_web_referemces[web_name]" value="<?php echo esc_attr($meta_data['web_name']);?>"/></td> 
						<th scope="row"><label><?php esc_html_e( 'Website URL', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_web_referemces[website]" value="<?php echo esc_attr($meta_data['website']);?>"/></td> 
					</tr>
				</tbody>
			</table>
		<?php
		}

		public function metabox_form_social(){
			$random_id 	= 'wd-team-member-metabox-'.mt_rand();
			$meta_key 	= 'wd_team_social';
			$meta_data 	= $this->get_meta_data($meta_key);
			$meta_data 	= empty($meta_data) ? $this->get_meta_data_default($meta_key) : $meta_data;
			?>
			<table id="<?php echo esc_attr( $random_id ); ?>" class="form-table wd-team-custom-meta-box wd-custom-meta-box-width">
				<tbody>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Facebook Link', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[facebook_link]" value="<?php echo esc_attr($meta_data['facebook_link']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[facebook_icon]" value="<?php echo esc_attr($meta_data['facebook_icon']);?>"/></td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Instagram', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[instagram_link]" value="<?php echo esc_attr($meta_data['instagram_link']);?>"/></td> 
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[instagram_icon]" value="<?php echo esc_attr($meta_data['instagram_icon']);?>"/></td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Twitter Link', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[twitter_link]" value="<?php echo esc_attr($meta_data['twitter_link']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[twitter_icon]" value="<?php echo esc_attr($meta_data['twitter_icon']);?>"/></td>
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Vimeo Link', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[vimeo_link]" value="<?php echo esc_attr($meta_data['vimeo_link']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[vimeo_icon]" value="<?php echo esc_attr($meta_data['vimeo_icon']);?>"/></td> 
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'RSS Link', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[rss_link]" value="<?php echo esc_attr($meta_data['rss_link']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[rss_icon]" value="<?php echo esc_attr($meta_data['rss_icon']);?>"/></td> 
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Google+ Link', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[google_link]" value="<?php echo esc_attr($meta_data['google_link']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[google_icon]" value="<?php echo esc_attr($meta_data['google_icon']);?>"/></td> 
					</tr>
					<tr>
						<th scope="row"><label><?php esc_html_e( 'Linkedln Link', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[linkedin_link]" value="<?php echo esc_attr($meta_data['linkedin_link']);?>"/></td>
						<th scope="row"><label><?php esc_html_e( 'Class Icon', 'wd_package' ); ?>:</label></th>
						<td><input type="text" class="wd-full-width" name="wd_team_social[linkedin_icon]" value="<?php echo esc_attr($meta_data['linkedin_icon']);?>"/></td> 
					</tr>
				</tbody>
			</table>
		<?php
		}

		public function metabox_form_role(){
			echo $this->get_metabox_repeatable_form( 'wd_team_role' );
		}

		public function metabox_form_work_experience(){
			echo $this->get_metabox_repeatable_form( 'wd_team_work_experiences' );
		}

		public function metabox_form_work_skill(){
			echo $this->get_metabox_repeatable_form( 'wd_team_skill' );
		}

		public function metabox_form_project(){
			$random_id 	= 'wd-team-member-metabox-'.mt_rand();
			$meta_key 	= 'wd_team_project';
			$meta_data 	= $this->get_meta_data($meta_key);
			$meta_data 	= empty($meta_data) ? $this->get_meta_data_default($meta_key) : $meta_data;
			$projects 	= wd_vc_get_data_by_post_type('portfolio');
			?>
			<table id="<?php echo esc_attr( $random_id ); ?>" class="form-table wd-product-field-custom-meta-box wd-custom-meta-box-width">
				<tbody>
					<tr>
						<?php $i = 1; ?>
						<?php foreach ($projects as $key => $project): ?>
							<?php $checked = in_array($project['value'], $meta_data) ? 'checked="true"' : '' ?>
							<td>
								<label class="container">
								 	<input type="checkbox" class="" name="wd_team_project[]" <?php echo $checked; ?> value="<?php echo $project['value']; ?>"/>
								 	<?php echo $project['label']; ?>
								</label>
							</td>
							<?php if ($i %4 == 0): ?>
								</tr></tr>
							<?php endif ?>
							<?php $i++; ?>
						<?php endforeach ?>
					</tr>
				</tbody>
			</table>
		<?php
		}

		public function get_metabox_repeatable_form( $meta_key = '' ){
			if (!$meta_key) return;
			$random_id 		= 'wd-team-member-metabox-'.mt_rand();
			$meta_data 		= $this->get_meta_data($meta_key);
			$meta_default 	= $this->get_meta_data_default($meta_key)[0];
			ob_start();
			?>
			<table id="<?php echo esc_attr( $random_id ); ?>" class="form-table wd-team-custom-meta-box wd-custom-meta-box-width">
			   <tbody>
				   	<?php
			        if ( $meta_data ) :
			          	foreach ( $meta_data as $value ) {
					         ?>
					      	<tr>
						        <?php echo $this->get_metabox_repeatable_field( $meta_key, $value ); ?>
						        <td width="10%"><a class="button wd-metabox-remove-row" href="#1"><?php esc_html_e( 'Remove', 'wd_package' ); ?></a></td>
					     	 </tr>
					      <?php
			         	}
			        else :
			         // show a blank one ?>
					     <tr>
			          		<?php echo $this->get_metabox_repeatable_field( $meta_key, $meta_default ); ?>
					        <td width="10%"><a class="button wd-metabox-remove-row button-disabled" href="#"><?php esc_html_e( 'Remove', 'wd_package' ); ?></a></td>
					      </tr>
			     	<?php endif; ?>
			
			      <!-- empty hidden one for jQuery -->
			      	<tr class="hidden wd_metabox_content_repeatable">
			         	<?php echo $this->get_metabox_repeatable_field( $meta_key, $meta_default ); ?>
			         	<td width="10%"><a class="button wd-metabox-remove-row" href="#"><?php esc_html_e( 'Remove', 'wd_package' ); ?></a></td>
			      	</tr>
			   	</tbody>
			</table>
			<p><a class="wd-metabox-add-row" data-id="<?php echo esc_attr( $random_id ); ?>" class="button" href="#"><?php esc_html_e( 'Add Another', 'wd_package' ); ?></a></p>
			<?php
			return ob_get_clean();
		}

		public function get_metabox_repeatable_field( $meta_key, $data = array() ){
			if (!empty($meta_key) && !empty($data)) {
				ob_start();
				switch ($meta_key) {
					case 'wd_team_role': ?>
							<td width="30%">
					        	<label><strong><?php esc_html_e( 'Role Name', 'wd_package' ); ?>:</strong></label>
					            <input type="text" class="wd-full-width"  placeholder="Ex: Graphic Design..." name="wd_team_role[role][]" value="<?php echo esc_attr( $data['role'] ); ?>" />
					        </td>
					        <td width="30%">
				            	<label><strong><?php esc_html_e( 'Company Name', 'wd_package' ); ?>:</strong></label>
				            	<input type="text" class="wd-full-width" placeholder="Enter company name..." name="wd_team_role[company_name][]" value="<?php echo esc_attr( $data['company_name'] ); ?>" />
					        </td>
					        <td width="30%">
					            <label><strong><?php esc_html_e( 'Company URL', 'wd_package' ); ?>:</strong></label>
					            <input type="text" class="wd-full-width" placeholder="Enter company url..." name="wd_team_role[company_url][]" value="<?php echo esc_attr( $data['company_url'] ); ?>" />
					        </td>

						<?php
						break;

					case 'wd_team_work_experiences': ?>
							<td width="30%">
					            <p>
					            	<label><strong><?php esc_html_e( 'Start Date', 'wd_package' ); ?>:</strong></label>
					            	<input type="text" class="wd-full-width datepicker-from"  placeholder="Choose a start date..." name="wd_team_work_experiences[date_start][]" value="<?php echo esc_attr( $data['date_start'] ); ?>" />
					            </p>
					            <p>
					            	<label><strong><?php esc_html_e( 'Company Name', 'wd_package' ); ?>:</strong></label>
					            	<input type="text" class="wd-full-width" placeholder="Enter company name..." name="wd_team_work_experiences[company_name][]" value="<?php echo esc_attr( $data['company_name'] ); ?>" />
					            </p>
					        </td>

			      			<td width="30%">
			      				<p>
					            	<label><strong><?php esc_html_e( 'End Date', 'wd_package' ); ?>:</strong></label>
					            	<input type="text" class="wd-full-width datepicker-to"  placeholder="Choose a end date..." name="wd_team_work_experiences[date_end][]" value="<?php echo esc_attr( $data['date_end'] ); ?>" />
					            </p>
					            <p>
					            	<label><strong><?php esc_html_e( 'Company URL', 'wd_package' ); ?>:</strong></label>
					            	<input type="text" class="wd-full-width" placeholder="Enter company url..." name="wd_team_work_experiences[company_url][]" value="<?php echo esc_attr( $data['company_url'] ); ?>" />
					            </p>
					        </td>
			      			<td width="30%">
			      				<label><strong><?php esc_html_e( 'Work Position', 'wd_package' ); ?>:</strong></label>
					            <textarea class="wd-full-width" placeholder="What did you do here?" cols="55" rows="5" name="wd_team_work_experiences[position][]"><?php echo esc_attr( $data['position'] ); ?></textarea>
					        </td>
						<?php
						break;

					case 'wd_team_skill': ?>
							<td width="45%">
				          		<label><strong><?php esc_html_e( 'Skill Name', 'wd_package' ); ?>:</strong></label>
					            <input type="text" class="wd-full-width"  placeholder="Ex: Graphic Design..." name="wd_team_skill[name][]" value="<?php echo esc_attr( $data['name'] ); ?>" />
					        </td>

					        <td width="45%">
					        	<div class="wd-range-slider">
					        		<label><strong><?php esc_html_e( 'Level', 'wd_package' ); ?>:</strong></label>
									<input class="wd-range-slider-range" type="range" min="0" max="100" name="wd_team_skill[level][]" value="<?php echo esc_attr( $data['level'] ); ?>" />
									<span class="wd-range-slider-value"><?php echo esc_attr( $value['level'] ); ?></span>
								</div>
					        </td>

						<?php
						break;

					default:
						break;
				}
				return ob_get_clean();
			}
		}

		public function change_title_text( $title ){
		    $screen = get_current_screen();
		  
		    if  ( $this->post_type == $screen->post_type ) {
		        $title = esc_html__( 'Enter Team Member Name', 'wd_package' );
		    }
		    return $title;
		}
		
		public function rename_second_menu_name($safe_text, $text) {
			if (__('Team Items', 'wd_package') !== $text) {
				return $safe_text;
			}

			// We are on the main menu item now. The filter is not needed anymore.
			remove_filter('attribute_escape', array($this,'rename_second_menu_name') );

			return __('WD Team', 'wd_package');
		}

		protected function initShortcodes(){
			foreach($this->arrShortcodes as $shortcode){
				if( file_exists(WDT_TEMPLATE."/wd_{$shortcode}.php") ){
					require_once WDT_TEMPLATE."/wd_{$shortcode}.php";
				}	
			}
		}

		public function initVisualComposer(){ 
			foreach ($this->arrShortcodes as $visual) {
				if( file_exists(WDT_TEMPLATE."/wd_vc_{$visual}.php") ){
					require_once WDT_TEMPLATE."/wd_vc_{$visual}.php";
				}
			}
	    }

		protected function init_handle(){
			add_image_size('wd-team-member-image-size-1',270,270,true);  
			add_image_size('wd-team-member-image-size-2',270,400,true);  
			add_image_size('wd-team-member-image-size-3',270,480,true);  
		}	
		
		public function init_admin_script($hook) {
			$screen = get_current_screen();
			if ($hook = 'post.php' && $this->post_type == $screen->post_type) {
				wp_enqueue_style('wd-team-admin-custom-css', WDT_ADMIN_CSS.'/wd_admin.css');	
				wp_enqueue_style('wd-team-admin-datepicker-css', WDT_ADMIN_CSS.'/datepicker.css');	
				wp_enqueue_style('wd-team-admin-normalize-css', WDT_ADMIN_CSS.'/normalize.css');	
				wp_enqueue_script( 'jquery-ui-datepicker');
				wp_enqueue_script( 'wd-team-scripts', WDT_ADMIN_JS.'/wd_script.js',false,false,true);
			}
			
		}	
		
		
		public function init_script(){
			wp_enqueue_style('wd-team-custom-css', WDT_CSS.'/wd_style.css');	
			wp_enqueue_script('wd-team-custom-scripts',  WDT_JS.'/wd_script.js',false,false,true);
		}


		/******************************** Check Visual Composer active ***********************************/
		protected function checkPluginVC(){
			$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
			if(in_array('js_composer/js_composer.php',$_active_vc)){
				return true;
			}else{
				return false;
			}
		}

	}
	WD_Team::get_instance();  // Start an instance of the plugin class 
}