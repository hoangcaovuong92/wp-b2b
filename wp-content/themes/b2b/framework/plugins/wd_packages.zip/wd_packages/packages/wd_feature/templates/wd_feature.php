<?php
/**
 * Shortcode: wd_feature
 */
if(!function_exists('wd_features_function')){
	function wd_features_function($atts){
		$atts = shortcode_atts(array(
			'id'						=> 0,
			'show_icon_font_thumbnail'	=> 'show-icon',
			'feature_icon_or_custom_icon' => 'feature_icon',
			'icon_fontawesome' 			=> 'fa fa-heartbeat',
			'icon_size'					=> 'fa-1x',
			'style_font'				=> 'sync-with-title',
			'image_or_thumbnail'		=> 'feature-thumbnail',
			'custom_image'				=> '',
			'image_size'				=> 'full',
			'text_align'				=> 'text-left',
			'title'						=> '1',
			'show_excerpt'				=> '1',
			'number_word'				=> '10',
			'readmore'					=> '0',
			'open_link_with'			=> 'modal',
			'readmore_text'				=> 'Read More',
			'style_class'				=> 'style-1',
			'class'						=> '',
		),$atts);
		$args_item 			= $atts;
		$args_item['type'] 	= 'single';
		extract($atts);

		if( absint($id) > 0 ){
			$args = array(
				'post_type'				=> 'wd_feature',
				'post__in' 				=> array($id),
				'post_status'			=> 'publish'
			);
			wp_reset_query();
			$_feature = new WP_Query($args);
		}else{
			return;
		}
		
		ob_start();
		if ( $_feature->have_posts() ) {
			while( $_feature->have_posts() ) { $_feature->the_post();
				echo wd_get_future_content_item($args_item); 
			}
		}
		$output = ob_get_clean();
		wp_reset_query();
		return $output;
	}
}
add_shortcode('wd_feature','wd_features_function');
?>