
//****************************************************************//
/*							Portfolio JS						  */
//****************************************************************//
jQuery( window ).ready( function ( $ ) {
	"use strict";

	//Isotope Layout
	setTimeout(function(){
		wd_portfolio_istope();
	}, 1500 );

	//Portfolio Grid
	wd_portfolio_grid_loadmore_ajax();

	//Portfolio Masonry
	wd_portfolio_masonry_loadmore_ajax();

	//Fancybox Gallery
	wd_portfolio_fancybox_gallery();

	//Filter
	wd_portfolio_filter_tool();

});

//****************************************************************//
/*							FUNCTIONS							  */
//****************************************************************//

//Isotope Layout
if (typeof wd_portfolio_istope != 'function') { 
	function wd_portfolio_istope() {
		if(jQuery('.wd-isotope').length > 0 ){
			jQuery( '.wd-isotope' ).isotope( {
				itemSelector: '.masonry-item',
				percentPosition: true,
				layoutMode: 'masonry',
			} );
		}
	}
}

//Portfolio Grid
if (typeof wd_portfolio_grid_loadmore_ajax != 'function') { 
	function wd_portfolio_grid_loadmore_ajax() {
		jQuery( document ).on( 'click', '.btn_loadmore_grid_portfolio', function ( event ) {
			event.preventDefault();
			var _this			= jQuery(this);
			var id_category 	= _this.data('id_category');
			var style 			= _this.data('style');
			var image_size 		= _this.data('image_size');
			var order_by 		= _this.data('order_by');
			var sort 			= _this.data('sort');
			var padding 		= _this.data('padding');
			var number_loadmore = _this.data('number_loadmore');
			var random_id 		= _this.data('random_id');
			var offset 			= _this.data('offset');

			_this.data('offset', (offset+number_loadmore) );

			jQuery.ajax( {
				url: portfolio_ajax_object.ajax_url,
				type: 'post',
				data: {
					action: 'load_more_portfolio_grid',
					offset: offset,
					id_category: id_category,
					style: style,
					image_size: image_size,
					order_by: order_by,
					sort: sort,
					padding: padding,
					number_loadmore: number_loadmore,
					random_id: random_id,
				},
				beforeSend: function () {
					jQuery( '#'+random_id+" .wd-icon-loading" ).css( 'display', 'block' );
				},
				error: function ( response ) {
					console.log( response );
				},
				success: function ( response ) {
					jQuery( '#'+random_id+" .wd-icon-loading" ).css( 'display', 'none' );
					if ( response === '0' ) {
						_this.parent().html( '<span>END OF POSTS</span>' );
					} else {
						jQuery('#'+random_id).find('.wd-portfolio-grid-list').append( response );
					}
				}
			} );
		} );
	}
}

//Portfolio Masonry
if (typeof wd_portfolio_masonry_loadmore_ajax != 'function') { 
	function wd_portfolio_masonry_loadmore_ajax() {
		var masonry_wrap = jQuery( '.grid-isotope' );
		jQuery( document ).on( 'click', '.btn_loadmore_masonry_portfolio', function ( event ) {
			event.preventDefault();
			var _this					 	= jQuery(this);
			var select_content_item_parent 	= _this.parents( '.wd-shortcode-masonry-portfolio' );
			var offset 					   	= _this.data('offset');
			var id_category 			   	= _this.data('id_category');
			var posts_per_page             	= _this.data( 'number' );
			var id_category                	= _this.data( 'id-category' );
			var sort                   	   	= _this.data( 'sort' );
			var order_by                   	= _this.data( 'order_by' );
			var image_size                 	= _this.data( 'image_size' );
			var tab_rand                   	= _this.data( 'tab-rand' );
			var style                      	= _this.data( 'style' );
			var padding                    	= _this.data( 'padding' );
			var grid_isotope               	= select_content_item_parent.find( '.wd-portfolio-masonry-list' );

			_this.data('offset', (offset+number_loadmore) );

			jQuery.ajax( {
				url: portfolio_ajax_object.ajax_url,
				type: 'post',
				data: {
					action: 'more_portfolio_masonry_ajax', 
					offset: offset,
					id_category: id_category,
					posts_per_page: posts_per_page,
					sort: sort,
					order_by: order_by,
					image_size: image_size,
					style: style,
					tab_rand: tab_rand,
					padding: padding,
				},
				beforeSend: function () {
					jQuery( ".wd-icon-loading" ).css( 'display', 'block' );
				},
				error: function ( response ) {
					console.log( response );
				},
				success: function ( response ) {
					jQuery( ".wd-icon-loading" ).css( 'display', 'none' );

					if ( response === '0' ) {
						jQuery( ".load_more_masonry" ).html( '<span>END OF POSTS</span>' );
					} else {
						var $response = jQuery( response );
						grid_isotope.append( $response );
						masonry_wrap.isotope( 'appended', $response );

						setTimeout(
							function(){
								masonry_wrap.isotope( 'layout' );
							}, 500
						);
					}
				}
			} );
		} );
	}
}

//Fancybox Gallery
if (typeof wd_portfolio_fancybox_gallery != 'function') { 
	function wd_portfolio_fancybox_gallery() {
		jQuery( '.wd-fancybox-thumbs' ).fancybox( {
			openEffect: 'elastic',
			closeEffect: 'elastic',
			closeBtn: false,

			helpers: {
				title	: {
					type: 'outside'
				},
				thumbs	: {
					width	: 50,
					height	: 50
				},
				overlay: {
					css: {
						'background': 'rgba(153, 174, 195, 0.85)'
					}
				}
			},

			beforeShow: function () {
				this.title = jQuery( this.element ).data( "caption" );
			}
		} );
	}
}

//Filter
if (typeof wd_portfolio_filter_tool != 'function') { 
	function wd_portfolio_filter_tool() {
		jQuery('.wd-portfolio-filter-by-cat a').click(function(e) {
			e.preventDefault();
			
			jQuery('.wd-portfolio-filter-by-cat-item').removeClass('active');
			jQuery(this).addClass('active');

			var filter_wrap 	= jQuery('.gallery .wd-filter-item');
			var a = jQuery(this).attr('href');
			a = a.substr(1);
			filter_wrap.each(function() {
				if (!jQuery(this).hasClass(a) && a != 'all')
					jQuery(this).addClass('hide').removeClass('masonry-item');
				else
					jQuery(this).removeClass('hide').addClass('masonry-item');
			});
			setTimeout(function(){
				wd_portfolio_istope();
			}, 500 );
		});

		/*jQuery('.gallery .grid-item').click(function(e) {
			e.preventDefault();
			var $i = jQuery(this);
			jQuery('.gallery .grid-item').not($i).toggleClass('pophide');
			$i.toggleClass('pop');
		});*/

		jQuery('.wd-portfolio-filter-by-columns .wd-portfolio-columns-select').change(function() {
			var current_column 	= jQuery(this).data('column');
			var new_column 		= jQuery(this).val();
			var element_wrap 	= jQuery('.wd-shortcode-masonry-portfolio, .wd-shortcode-grid-portfolio');
			if (current_column !== new_column) {
				element_wrap.addClass('wd-columns-' + new_column).removeClass('wd-columns-' + current_column);
				jQuery(this).data('column', new_column);
				setTimeout(function(){
					wd_portfolio_istope();
				}, 500 );
			}
		});
	}
}

