<?php
/**
 * Shortcode: wd_special_gird_list_blog
 */

if ( ! function_exists( 'wd_portfolio_gird' ) ) {
	function wd_portfolio_gird( $atts ) {
		extract(shortcode_atts( array(
			'id_category'         	=> '-1',
			'number_portfolio'    	=> '12',
			'style'               	=> 'wd-portfolio-style-1',
			'image_size'			=> 'full',
			'order_by'            	=> 'DESC',
			'sort'                	=> 'term_id',
			'columns'             	=> '1',
			'columns_tablet'		=> 2,
			'columns_mobile'		=> 1,
			'padding'               => '0',
			'excerpt_words'       	=> '20',
			'pagination_loadmore' 	=> 'loadmore',
			'number_loadmore'     	=> '8',
			'class'               	=> '',
		), $atts ) );

		// New blog
		$args = array(
			'post_type'      => 'portfolio',
			'posts_per_page' => $number_portfolio,
			'orderby'        => $sort,
			'order'          => $order_by,
			'paged'          => get_query_var( 'paged' ),
		);

		// Category
		if ( $id_category != - 1 ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'wd-portfolio-category',
					'terms'    => explode(',' , $id_category),
					'field'    => 'term_id',
					'operator' => 'IN',
				),
			);
		}
		// Most View Products
		$special_portfolio = new WP_Query( $args );

		$style_padding_item = ($padding) ? 'padding:'.$padding.'px;' : '' ;
		$style_wrap_item 	= ($padding) ? 'margin-left:-'.$padding.'px; margin-right:-'.$padding.'px;' : '' ;
		$span_class 		= 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile;
		$random_number      = mt_rand();
		$random_id        	= 'wd-portfolio-grid-'.$random_number;

		ob_start(); ?>
		<?php if ( $special_portfolio->have_posts() ) : ?>
			<div class="row wd-shortcode-grid-portfolio <?php echo esc_attr( $span_class ); ?> <?php esc_html_e( $style ); ?> <?php esc_html_e( $class ); ?>" id="<?php echo esc_attr( $random_id ); ?>">
					<?php if ($pagination_loadmore == "filter"): ?>
				     	<?php wd_portfolio_filter_tools($random_number, $id_category, $columns); ?>
				     <?php endif ?>

					<ul class="wd-portfolio-grid-list gallery"  style="<?php echo esc_attr( $style_wrap_item ); ?>">
						<?php while ( $special_portfolio->have_posts() ) : $special_portfolio->the_post();
							include( WDP_BASE . '/templates/partials/portfolio_grid.php' );
						endwhile; ?>
					</ul><!-- .grid -->

				<div class="clear clearfix"></div>

				<?php if ( $pagination_loadmore == "pagination" && $number_portfolio > 0 ) : ?>
					<div class="wd-pagination">
						<?php echo apply_filters('wd_filter_display_pagination',  3, $special_portfolio ) ?>
					</div><!-- .wd-pagination -->
				<?php endif; ?>

				<?php if ( $pagination_loadmore == "loadmore" && $number_portfolio > 0 ) : ?>
					<div class="wd-loadmore">
						<div style="display: none;" class="wd-icon-loading">
							<img src="<?php echo WDP_IMAGE . '/ajax-loader_image.gif'; ?>" alt="HTML5 Icon" style="height:15px;">
						</div><!-- .wd-icon-loading -->

						<div id="loadmore">
							<a href="#"
							   class="button btn_loadmore_grid_portfolio"
							   data-number_loadmore="<?php esc_html_e( $number_loadmore ); ?>"
							   data-id_category="<?php esc_html_e( $id_category ); ?>"
							   data-image_size="<?php esc_html_e( $image_size ); ?>"
							   data-order_by="<?php esc_html_e( $order_by ); ?>"
							   data-sort="<?php esc_html_e( $sort ); ?>"
							   data-padding="<?php esc_html_e( $padding ); ?>"
							   data-style="<?php esc_html_e( $style ); ?>"
							   data-random_id="<?php echo $random_id; ?>"
							   data-offset="<?php echo $number_portfolio; ?>">
								<?php _e( 'LOAD MORE', 'wd_package' ) ?></a> 
						</div><!-- #loadmore -->
					</div><!-- .wd-loadmore -->
				<?php endif; ?>
			</div><!-- .wd-wrapper-special-grid -->
			<?php wp_reset_postdata(); ?>
		<?php endif;
		$content = ob_get_clean();

		return $content;
	}
}
add_shortcode('wd_portfolio_gird', 'wd_portfolio_gird' );
?>