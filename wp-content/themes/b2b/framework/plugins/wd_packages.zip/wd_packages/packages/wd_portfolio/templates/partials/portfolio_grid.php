<?php
if ( has_post_thumbnail() && get_the_post_thumbnail() ) {
	$thumbnail_id 	= get_post_thumbnail_id( get_the_ID() );
	$thumbnail_src 	= wp_get_attachment_image_src( $thumbnail_id, 'full');

	//$light_box_url = trim( WD_Portfolio::wd_portfolio_get_meta( 'wd-portfolio' ) );
	//if ( strlen( $light_box_url ) <= 0 ) {
	$light_box_url = $thumbnail_src[0];
	//}

	$thumbnail_img = get_the_post_thumbnail( null, $image_size );
} else {
	$light_box_url = WDP_IMAGE . '/600x364.png';
	$thumbnail_img = '<img width="600" height="364" src="' . $light_box_url . '" class="attachment-portfolio_image size-portfolio_image wp-post-image" alt="">';
}
$light_box_class = WD_Portfolio::wd_portfolio_get_filetype( $light_box_url );

$style_padding_item = ($padding) ? 'padding:'.$padding.'px;' : '' ;
?>
<li class="grid-item wd-filter-item wd-wrap-content-item <?php wd_portfolio_class_slug_category(); ?>" style="<?php echo esc_attr( $style_padding_item ); ?>">
	<div class="wd-wrap-content-inner">
		<div class="wd-thumbnail-post">
			
			<a class="zoom-gallery wd-fancybox-thumbs <?php echo esc_attr( $light_box_class ); ?>"
			   data-toggle="tooltip"
			   data-fancybox-group="<?php echo $random_id; ?>"
			   title="<?php _e( 'Quick View', 'wd_package' ) ?>"
			   data-caption="<?php the_title(); ?>"
			   href="<?php echo esc_url( $light_box_url ); ?>">
				<?php echo $thumbnail_img; ?>
			</a>

			<?php if ( $style == 'wd-portfolio-style-1' || $style == 'wd-portfolio-style-3' ) : ?>
				<div class="hover-default thumb-image-hover">
					<div class="wd-title-portfolio">
						<h2 class="wd-heading-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>
					</div>
					<div class="icons">
						<a class="link-gallery"
						   data-toggle="tooltip"
						   title="<?php _e( "View Details", 'wd_package' ); ?>"
						   href="<?php the_permalink(); ?>"><?php esc_html_e( 'Readmore', 'wd_package' ); ?></a>
					</div><!-- .icons -->
				</div><!-- .hover-default -->
			<?php endif; ?>
		</div><!-- .wd-thumbnail-post -->

		<?php if ( $style == 'wd-portfolio-style-2' ) : ?>
			<div class="wd-content-portfolio">
				<div class="wd-title-portfolio">
					<h2 class="wd-heading-title">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h2>
				</div>
				<div class="wd-category-portfolio">
					<?php $post_categories = get_the_term_list( get_the_ID(), 'wd-portfolio-category', '', ' , ', '' ); ?>
					<?php echo( $post_categories ); ?>
				</div><!-- .wd-category-portfolio -->
				<div class="wd-content-portfolio">
					<?php the_content(); ?>
				</div>
				<div class="icons">
					<a class="link-gallery" data-toggle="tooltip" title="<?php _e( "View Details", 'wd_package' ); ?>" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Readmore', 'wd_package' ); ?></a>
				</div><!-- .icons -->
			</div><!-- .wd-content-portfolio -->
		<?php endif; ?>
	</div><!-- .wd-wrap-content-inner -->
</li><!-- .wd-wrap-content-item -->