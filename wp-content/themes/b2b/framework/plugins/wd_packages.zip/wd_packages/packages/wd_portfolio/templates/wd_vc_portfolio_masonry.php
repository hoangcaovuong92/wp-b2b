<?php
# Visual Composer installed?
if ( function_exists( 'visual_composer' ) && ! function_exists( 'wd_vc_shortcodes_portfolio_masonry' ) ) {
	/**
	 * Add theme's custom shortcodes to Visual Composer
	 */
	function wd_vc_shortcodes_portfolio_masonry() {
		$categories  = wd_vc_get_list_category('wd-portfolio-category', false, 'sorted_list');
		vc_map( array(
			'name'        => __( 'WD - Portfolio Masonry', 'wd_package' ),
			'base'        => 'wd_portfolio_masonry',
			'description' => __( 'Style masonry of portfolio', 'wd_package' ),
			'category'    => esc_html__("WD - Content", 'wd_package'),
			'icon'        => 'vc_icon-vc-masonry-grid',
			'params'      => array(
				array(
					'type' 			=> 'sorted_list',
					'heading' 		=> __( 'Categories', 'wd_package' ),
					'param_name' 	=> 'id_category',
					'description' 	=> __( 'Select and sort portfolio categories. Leave blank if you want to display all portfolio category', 'wd_package' ),
					'value' 		=> '-1',
					'options' 		=> $categories,
					'dependency'  	=> array('element' => 'type', 'value'   => array( 'categories' )),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Style', 'wd_package' ),
					'param_name'  => 'style',
					'admin_label' => true,
					'value'       => array(
						__( 'Style 1', 'wd_package' ) => 'portfolio-style-1',
						__( 'Style 2', 'wd_package' ) => 'portfolio-style-2',
					),
					'description' => '', 
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Number Portfolio', 'wd_package' ),
					'description' => __( 'number', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'number',
					'value'       => '6',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Sort By', 'wd_package' ),
					'param_name'  => 'sort',
					'admin_label' => true,
					'value'       => array(
						__( 'Date', 'wd_package' ) => 'date',
						__( 'Name', 'wd_package' ) => 'name',
						__( 'Slug', 'wd_package' ) => 'slug',
					),
					'description' => '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Order By', 'wd_package' ),
					'param_name'  => 'order_by',
					'admin_label' => true,
					'value'       => array(
						'DESC' => 'DESC',
						'ASC'  => 'ASC',
					),
					'description' => '',
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Columns', 'wd_package' ),
					'param_name'  => 'columns',
					'admin_label' => true,
					'value'       => array(
						__( '1 Columns', 'wd_package' ) => '1',
						__( '2 Columns', 'wd_package' ) => '2',
						__( '3 Columns', 'wd_package' ) => '3',
						__( '4 Columns', 'wd_package' ) => '4',
						__( '6 Columns', 'wd_package' ) => '6',
					),
					'description' => '',
				),
				array(
					'type' 				=> 'dropdown',
					'heading' 			=> esc_html__( 'Columns On Tablet', 'wd_package' ),
					'param_name' 		=> 'columns_tablet',
					'admin_label' 		=> true,
					'value' 			=> wd_vc_get_list_columns_tablet(),
					'std'				=> 2,
					'description' 		=> esc_html__( '', 'wd_package' ),
					"group"				=> esc_html__('Responsive', 'wd_package'),
				),
				array(
					'type' 				=> 'dropdown',
					'heading' 			=> esc_html__( 'Columns On Mobile', 'wd_package' ),
					'param_name' 		=> 'columns_mobile',
					'admin_label' 		=> true,
					'value' 			=> wd_vc_get_list_columns_mobile(),
					'std'				=> 1,
					'description' 		=> esc_html__( '', 'wd_package' ),
					"group"				=> esc_html__('Responsive', 'wd_package'),
				),
				array(
					"type" 			=> "textfield",
					"class" 		=> "",
					"heading" 		=> esc_html__("Padding", 'wd_package'),
					"param_name" 	=> "padding",
					"value"			=> 0,
					"description" 	=> esc_html__('Padding between images. Only fill in whole numbers or real numbers. Example: 2.5 (Unit: pixels)', 'wd_package'),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => __( 'Show Pagination Or Load More', 'wd_package' ),
					'param_name'  => 'pagination_loadmore',
					'admin_label' => true,
					'value'       => array(
						__( 'Load More', 'wd_package' )  => 'loadmore',
						__( 'Pagination', 'wd_package' ) => 'pagination',
						__( 'Filter', 'wd_package' ) 	 => 'filter',
						__( 'No Show', 'wd_package' )    => '0',
					),
					'description' => '',
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Number Post Load More', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'number_loadmore',
					'value'       => '6',
					'description' => '',
					'dependency'  => Array( 'element' => 'pagination_loadmore', 'value' => array( '0' ) ),
				),
				array(
					'type'        => 'textfield',
					'class'       => '',
					'heading'     => __( 'Extra class name', 'wd_package' ),
					'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'wd_package' ),
					'admin_label' => true,
					'param_name'  => 'class',
					'value'       => '',
				),
			),
		) );
	}
}

# add theme's custom shortcodes to Visual Composer
add_action( 'vc_before_init', 'wd_vc_shortcodes_portfolio_masonry' );
