<?php
	// Currency Switcher
	vc_map(array(
		'name' 				=> esc_html__("WD - Woo Currency Switcher", 'wd_package'),
		'base' 				=> 'wd_currency_switcher',
		'description' 		=> esc_html__("Currency Switcher", 'wd_package'),
		'category' 			=> esc_html__("WD - Nav User", 'wd_package'),
		'icon'        		=> 'icon-wpb-woocommerce',
		'params' => array(
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Style', 'wd_package' ),
				'param_name' 	=> 'style',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Dropdown'		=> 'dropdown',
					'Button'		=> 'button',
				),
				'std'			=> '0',
				'description' 	=> esc_html__('', 'wd_package')
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Title', 'wd_package' ),
				'param_name' 	=> 'title',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Show Symbol'				=> 'symbol',
					'Show Currency'				=> 'currency',
					'Show Fullname'				=> 'name',
					'Show Fullname & Symbol'	=> 'name-symbol',
					'Show Fullname & Currency'	=> 'name-currency',
					'Show Currency & Symbol'	=> 'currency-symbol',
				),
				'std'			=> '0',
				'description' 	=> esc_html__('', 'wd_package')
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Show reset', 'wd_package' ),
				'param_name' 	=> 'show_reset',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Yes'			=> '1',
					'No'			=> '0',
				),
				'std'			=> '0',
				'description' 	=> esc_html__('', 'wd_package')
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Display Flag', 'wd_package' ),
				'param_name' 	=> 'show_flag',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Yes'		=> '1',
					'No'		=> '0'
				),
				'std'			=> '0',
				'description' 	=> esc_html__('Display icon flag', 'wd_package')
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Flag Position', 'wd_package' ),
				'param_name' 	=> 'flag_position',
				'admin_label' 	=> true,
				'value' 		=> array(
					'Left'		=> 'left',
					'Right'		=> 'right',
				),
				'std'			=> '0',
				'dependency'  	=> array('element' => "show_flag", 'value' => array('1'))
			),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wd_package'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wd_package'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
?>