<?php
/**
 * Shortcode: wd_feature_counter
 */
if(!function_exists('wd_feature_counter_function')){
	function wd_feature_counter_function($atts){
		extract(shortcode_atts(array(
			'items'						=> '',
			'show_counter'				=> '1',
			'show_icon_font_image'		=> 'show-image',
			'image_size'				=> 'full',
			'thumbnail_position'		=> 'between-title-content',
			'columns'					=> 4,
			'columns_tablet'			=> 2,
			'columns_mobile'			=> 1,
			'text_align'				=> 'text-left',
			'counter_step'				=> '1',
			'counter_duration'			=> '2000',
			'style_class'				=> 'style-1',
			'class'						=> '',
		),$atts));
		if (!function_exists('vc_param_group_parse_atts')) return;
		
		$items 				= vc_param_group_parse_atts( $items );
		$random_id 			= 'wd-feature-counter-'.mt_rand();
		$style_class		= 'wd-feature-counter-'.$style_class;
		$columns_feature 	= 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile;
		$counter_duration 	= !($counter_duration) ? 2000 : $counter_duration;
		ob_start();
		if ( !empty($items) ) { ?>
			<div id="<?php echo esc_attr($random_id); ?>" class="wd-feature-counter-wrapper <?php echo esc_attr($columns_feature); ?> <?php echo esc_attr($class); ?>">
				<ul>
					<?php foreach ($items as $item): ?>
						<?php 
						$counter_start 		= (empty($item['counter_start'])) ? 100 : $item['counter_start'];
						$counter_end 		= (empty($item['counter_end'])) ? 100 : $item['counter_end'];
						$counter_title 		= (empty($item['title'])) ? '' : $item['title'];
						$counter_desc 		= (empty($item['description'])) ? '' : $item['description'];
						$main_image_icon	= '';
						if ($show_icon_font_image == 'show-image' && !empty($item['image'])) {
							$image 			= explode(',', $item['image']);
							$image_attr				= array(
								'alt' 		=> get_bloginfo('name').' - Feature counter image',
								'title' 	=> get_bloginfo('name').' - Feature counter image',
							);
							ob_start();
							echo $main_img_url 	= '<div class="wd-feature-counter-main-image">'.wp_get_attachment_image($image['0'], $image_size, false, $image_attr).'</div>';
							echo $hover_img_url 	= !(empty($image['1'])) ? '<div class="wd-feature-counter-hover-image">'.wp_get_attachment_image($image['1'], $image_size, false, $image_attr).'</div>' : '';
							$main_image_icon = ob_get_clean();
						}elseif ($show_icon_font_image == 'show-icon-font' && !empty($item['icon'])){
							$main_image_icon = '<div class="wd-feature-counter-main-icon"><span class="'. esc_attr($item['icon']).'"></span></div>';
						}
						?>
						<li class="wd-feature-counter-item <?php echo esc_attr($style_class); ?> <?php echo esc_attr($text_align); ?>" >
							<?php if ($thumbnail_position == 'above-title-content' && $main_image_icon){
								echo $main_image_icon;
							} ?>

							<?php if ($counter_title != ''): ?>
								<p class="wd-feature-counter-title"><?php echo esc_html( $counter_title ); ?></p>	
							<?php endif ?>	

							<?php if ($thumbnail_position == 'between-title-content' && $main_image_icon){
								echo $main_image_icon;
							} ?>

							<?php if ($show_counter && $counter_start && $counter_end): ?>
								<p class="wd-counter-wrapper">
									<span 	class="wd-feature-counter-start" 
											data-counter_start="<?php echo esc_attr($counter_start); ?>" 
											data-counter_end="<?php echo esc_attr($counter_end); ?>" 
											data-counter_duration="<?php echo esc_attr($counter_duration); ?>">
									</span>
								</p>
							<?php endif ?>

							<?php if ($counter_desc != ''): ?>
								<p class="wd-feature-counter-desc"><?php echo esc_html( $counter_desc ); ?></p>	
							<?php endif ?>	
							
							<?php if ($thumbnail_position == 'below-title-content' && $main_image_icon){
								echo $main_image_icon;
							} ?>
							
						</li>
					<?php endforeach ?>
				</ul>
			</div>
			
			<?php
		}
		$output = ob_get_clean();
		wp_reset_query();
		return $output;
	}
}
add_shortcode('wd_feature_counter','wd_feature_counter_function');
?>