<?php
/**
 * Shortcode: wd_team_member
 */

if (!function_exists('wd_team_member_category_function')) {
	function wd_team_member_category_function($atts) {
		extract(shortcode_atts(array(
			'id_category'		=> '-1',
			'columns'			=> '4',
			'columns_tablet'	=> 2,
			'columns_mobile'	=> 1,
			'number_teammember'	=> '8',
			'image_size'		=> 'wd-team-member-image-size-1',
			'number_word'		=> '50',
			'style'				=> 'style-1',
			'padding'			=> '15',
			'is_slider'			=> '1',
			'show_nav'			=> '1',
			'auto_play'			=> '1',
			'class'				=> ''
		), $atts));

		$args 	= array( 
			'post_type' 		=> 'team',
			'post_status' 		=> 'publish',
			'posts_per_page' 	=> $number_teammember,
		);
		$style_class 		= 'wd-team-member-'.$style;	

		if($id_category != '-1'){
			$args['tax_query'][] = array(
				'taxonomy' 			=> 'team_categories',
	            'field' 			=> 'id', //get by slug or term_id
	            'terms' 			=> explode(',', $id_category),
	            'include_children' 	=> true,
				'operator' 			=> 'IN'
			);
		}
		wp_reset_postdata();
		if ($is_slider) {
			$wrap_class = '';
			$list_class	= 'wd-slider-wrap wd-slider-wrap--blog-special';
			$slider_options = json_encode(array(
				'slider_type' => 'owl',
				'column_desktop' => esc_attr($columns),
				'column_tablet' => esc_attr($columns_tablet),
				'column_mobile' => esc_attr($columns_mobile),
				'arrows' => $show_nav ? true : false,
				'autoplay' => $auto_play ? true : false,
			));
		}else{
			$wrap_class = ($is_slider == '0') ? 'wd-columns-'.$columns.' wd-tablet-columns-'.$columns_tablet.' wd-mobile-columns-'.$columns_mobile : '';
			$list_class	= 'wd-columns-list-item';
			$slider_options	= '';
		}
		$teammember 	= new WP_Query($args);
		ob_start(); ?>
		<div class="wd-team-member <?php echo esc_attr($style_class) ?> <?php echo esc_attr( $wrap_class ); ?> <?php echo esc_attr($class) ?>" >
			<?php if( $teammember->have_posts() ) :?> 
				<ul class="wd-team-category-list <?php echo esc_attr( $list_class ); ?>" 
					data-slider-options='<?php echo esc_attr( $slider_options ); ?>'>
					<?php while ($teammember->have_posts()) : $teammember->the_post(); global $post; ?>
						<?php echo wd_team_member_get_loop_template($style, $is_slider, $padding); ?>
					<?php endwhile;// End While ?> 
				</ul>
			<?php endif; ?>
		</div>
		<?php
		$content = ob_get_clean();
		wp_reset_postdata();
		return $content;
	}
}
add_shortcode('wd_team_member_category', 'wd_team_member_category_function');